import React from 'react';
import {Composition} from 'remotion';
import {MainComposition} from './compositions/MainComposition';
import {OpeningScene} from './scenes/OpeningScene';
import {AboutScene} from './scenes/AboutScene';
import {IndustryScene} from './scenes/IndustryScene';
import {SmartFarmScene} from './scenes/SmartFarmScene';
import {HonorsScene} from './scenes/HonorsScene';
import {EndingScene} from './scenes/EndingScene';

export const Root: React.FC = () => {
  return (
    <>
      {/* 主合成 - 完整 3 分钟宣传片 */}
      <Composition
        id="MainComposition"
        component={MainComposition}
        durationInFrames={5400} // 180 秒 * 30fps
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{
          companyName: '新疆上禾智慧农业发展有限责任公司',
          englishName: 'SHANGHE SMART AGRICULTURE',
          registeredCapital: '5000 万元',
          breedingScale: '1000000+ 头/只',
          plantingArea: '50000+ 亩',
          staffCount: '100+ 人',
          serviceFarmers: '10000+ 户',
          phone: '086-0999-5036228',
          address: '中国新疆伊犁新源县 72 团农业产业园',
          website: 'https://master.shanghe-agri-website.pages.dev'
        }}
      />
      
      {/* 独立场景 - 可用于单独渲染或测试 */}
      <Composition
        id="OpeningScene"
        component={OpeningScene}
        durationInFrames={450} // 15 秒
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{
          companyName: '新疆上禾智慧农业发展有限责任公司',
          englishName: 'SHANGHE SMART AGRICULTURE'
        }}
      />
      
      <Composition
        id="AboutScene"
        component={AboutScene}
        durationInFrames={900} // 30 秒
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{
          registeredCapital: '5000 万元',
          breedingScale: '1000000+ 头/只',
          plantingArea: '50000+ 亩',
          staffCount: '100+ 人',
          serviceFarmers: '10000+ 户'
        }}
      />
      
      <Composition
        id="IndustryScene"
        component={IndustryScene}
        durationInFrames={1350} // 45 秒
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{}}
      />
      
      <Composition
        id="SmartFarmScene"
        component={SmartFarmScene}
        durationInFrames={900} // 30 秒
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{}}
      />
      
      <Composition
        id="HonorsScene"
        component={HonorsScene}
        durationInFrames={600} // 20 秒
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{}}
      />
      
      <Composition
        id="EndingScene"
        component={EndingScene}
        durationInFrames={600} // 20 秒
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{
          companyName: '新疆上禾智慧农业发展有限责任公司',
          phone: '086-0999-5036228',
          address: '中国新疆伊犁新源县 72 团农业产业园',
          website: 'https://master.shanghe-agri-website.pages.dev'
        }}
      />
    </>
  );
};
