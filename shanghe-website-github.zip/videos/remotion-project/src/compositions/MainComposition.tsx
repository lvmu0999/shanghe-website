import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {OpeningScene} from '../scenes/OpeningScene';
import {AboutScene} from '../scenes/AboutScene';
import {IndustryScene} from '../scenes/IndustryScene';
import {SmartFarmScene} from '../scenes/SmartFarmScene';
import {HonorsScene} from '../scenes/HonorsScene';
import {EndingScene} from '../scenes/EndingScene';

interface MainCompositionProps {
  companyName: string;
  englishName: string;
  registeredCapital: string;
  breedingScale: string;
  plantingArea: string;
  staffCount: string;
  serviceFarmers: string;
  phone: string;
  address: string;
  website: string;
}

export const MainComposition: React.FC<MainCompositionProps> = (props) => {
  const frame = useCurrentFrame();
  const [showSubtitle, setShowSubtitle] = useState(false);
  
  useEffect(() => {
    // 3 秒后显示字幕（可选功能）
    const timer = setTimeout(() => setShowSubtitle(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AbsoluteFill style={{backgroundColor: '#fff'}}>
      {/* 0:00-0:15 开场 */}
      <Sequence from={0} durationInFrames={450}>
        <OpeningScene 
          companyName={props.companyName}
          englishName={props.englishName}
        />
      </Sequence>
      
      {/* 0:15-0:45 企业概况 */}
      <Sequence from={450} durationInFrames={900}>
        <AboutScene
          registeredCapital={props.registeredCapital}
          breedingScale={props.breedingScale}
          plantingArea={props.plantingArea}
          staffCount={props.staffCount}
          serviceFarmers={props.serviceFarmers}
        />
      </Sequence>
      
      {/* 0:45-1:30 产业布局 */}
      <Sequence from={1350} durationInFrames={1350}>
        <IndustryScene />
      </Sequence>
      
      {/* 1:30-2:00 智慧农业 */}
      <Sequence from={2700} durationInFrames={900}>
        <SmartFarmScene />
      </Sequence>
      
      {/* 2:00-2:20 荣誉资质 */}
      <Sequence from={3600} durationInFrames={600}>
        <HonorsScene />
      </Sequence>
      
      {/* 2:20-2:40 社会责任 (合并到结尾) */}
      
      {/* 2:40-3:00 结尾 */}
      <Sequence from={4200} durationInFrames={600}>
        <EndingScene
          companyName={props.companyName}
          phone={props.phone}
          address={props.address}
          website={props.website}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
