import {registerRoot} from 'remotion';

// Register the root component for Remotion
registerRoot(require('./src/Root').Root);
