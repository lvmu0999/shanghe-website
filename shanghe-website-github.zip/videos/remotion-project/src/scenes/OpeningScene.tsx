import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate, useVideoConfig} from 'remotion';

interface OpeningSceneProps {
  companyName: string;
  englishName: string;
}

export const OpeningScene: React.FC<OpeningSceneProps> = ({companyName, englishName}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  
  // 淡入动画
  const opacity = interpolate(frame, [0, 60], [0, 1], {extrapolateRight: 'clamp'});
  
  // LOGO 缩放动画
  const logoScale = interpolate(frame, [0, 90], [0.5, 1], {
    extrapolateRight: 'clamp',
    easing: 'ease-out'
  });
  
  // 标题上移动画
  const titleY = interpolate(frame, [30, 90], [50, 0], {
    extrapolateRight: 'clamp',
    easing: 'ease-out'
  });
  
  // 副标题淡入
  const subtitleOpacity = interpolate(frame, [60, 120], [0, 1], {extrapolateRight: 'clamp'});

  return (
    <AbsoluteFill>
      {/* 背景渐变 - 模拟晨曦天空 */}
      <div 
        style={{
          width: '100%',
          height: '100%',
          background: 'linear-gradient(180deg, #FF8C42 0%, #FFA94D 30%, #FFD93D 60%, #81C784 100%)',
          opacity
        }}
      />
      
      {/* 装饰性光晕 */}
      <div 
        style={{
          position: 'absolute',
          top: '20%',
          left: '50%',
          transform: 'translateX(-50%)',
          width: '600px',
          height: '600px',
          background: 'radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%)',
          borderRadius: '50%',
          filter: 'blur(40px)'
        }}
      />
      
      {/* 内容容器 */}
      <div 
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          opacity
        }}
      >
        {/* LOGO */}
        <div 
          style={{
            transform: `scale(${logoScale}) translateY(${titleY}px)`,
            marginBottom: '40px'
          }}
        >
          <svg 
            viewBox="0 0 100 100" 
            width="150" 
            height="150"
            style={{
              filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.2))'
            }}
          >
            <circle cx="50" cy="50" r="48" fill="#2E7D32"/>
            <path 
              d="M50 20 L60 45 L85 45 L65 60 L75 85 L50 70 L25 85 L35 60 L15 45 L40 45 Z" 
              fill="#81C784"
              style={{
                filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.2))'
              }}
            />
          </svg>
        </div>
        
        {/* 公司中文名 */}
        <h1 
          style={{
            fontSize: '56px',
            fontWeight: 'bold',
            color: '#FFFFFF',
            margin: '0 0 20px 0',
            textShadow: '0 2px 8px rgba(0,0,0,0.3)',
            transform: `translateY(${titleY}px)`,
            letterSpacing: '8px'
          }}
        >
          {companyName}
        </h1>
        
        {/* 公司英文名 */}
        <p 
          style={{
            fontSize: '28px',
            color: '#FFFFFF',
            margin: 0,
            opacity: subtitleOpacity,
            textShadow: '0 2px 4px rgba(0,0,0,0.3)',
            letterSpacing: '4px',
            fontWeight: '300'
          }}
        >
          {englishName}
        </p>
      </div>
      
      {/* 底部装饰线条 */}
      <div 
        style={{
          position: 'absolute',
          bottom: '60px',
          left: '10%',
          right: '10%',
          height: '2px',
          background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.8), transparent)',
          opacity
        }}
      />
    </AbsoluteFill>
  );
};
