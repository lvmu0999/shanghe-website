import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate, useVideoConfig} from 'remotion';

interface AboutSceneProps {
  registeredCapital: string;
  breedingScale: string;
  plantingArea: string;
  staffCount: string;
  serviceFarmers: string;
}

export const AboutScene: React.FC<AboutSceneProps> = (props) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  
  // 背景淡入
  const bgOpacity = interpolate(frame, [0, 30], [0, 1], {extrapolateRight: 'clamp'});
  
  // 标题动画
  const titleOpacity = interpolate(frame, [20, 50], [0, 1], {extrapolateRight: 'clamp'});
  const titleY = interpolate(frame, [20, 50], [30, 0], {extrapolateRight: 'clamp'});
  
  // 数据卡片依次出现
  const cards = [
    {label: '注册资金', value: props.registeredCapital, delay: 0},
    {label: '养殖规模', value: props.breedingScale, delay: 15},
    {label: '种植基地', value: props.plantingArea, delay: 30},
    {label: '员工数量', value: props.staffCount, delay: 45},
    {label: '服务农户', value: props.serviceFarmers, delay: 60}
  ];

  return (
    <AbsoluteFill>
      {/* 背景 */}
      <div 
        style={{
          width: '100%',
          height: '100%',
          background: 'linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 50%, #A5D6A7 100%)',
          opacity: bgOpacity
        }}
      />
      
      {/* 装饰性圆形 */}
      <div 
        style={{
          position: 'absolute',
          top: '-200px',
          right: '-200px',
          width: '600px',
          height: '600px',
          background: 'radial-gradient(circle, rgba(46,125,50,0.1) 0%, transparent 70%)',
          borderRadius: '50%'
        }}
      />
      
      {/* 内容 */}
      <div 
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '60px'
        }}
      >
        {/* 标题 */}
        <div 
          style={{
            opacity: titleOpacity,
            transform: `translateY(${titleY}px)`,
            textAlign: 'center',
            marginBottom: '60px'
          }}
        >
          <h2 
            style={{
              fontSize: '48px',
              fontWeight: 'bold',
              color: '#2E7D32',
              margin: '0 0 16px 0',
              letterSpacing: '6px'
            }}
          >
            企业概况
          </h2>
          <p 
            style={{
              fontSize: '20px',
              color: '#555',
              margin: 0,
              letterSpacing: '2px'
            }}
          >
            ABOUT SHANGHE
          </p>
        </div>
        
        {/* 数据卡片网格 */}
        <div 
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '30px',
            width: '100%',
            maxWidth: '1200px'
          }}
        >
          {cards.map((card, index) => {
            const cardOpacity = interpolate(
              frame, 
              [60 + card.delay, 90 + card.delay], 
              [0, 1], 
              {extrapolateRight: 'clamp'}
            );
            const cardY = interpolate(
              frame, 
              [60 + card.delay, 90 + card.delay], 
              [40, 0], 
              {extrapolateRight: 'clamp'}
            );
            const cardScale = interpolate(
              frame, 
              [60 + card.delay, 100 + card.delay], 
              [0.9, 1], 
              {extrapolateRight: 'clamp'}
            );
            
            return (
              <div
                key={index}
                style={{
                  background: 'white',
                  borderRadius: '16px',
                  padding: '40px 30px',
                  textAlign: 'center',
                  boxShadow: '0 8px 24px rgba(46,125,50,0.15)',
                  opacity: cardOpacity,
                  transform: `translateY(${cardY}px) scale(${cardScale})`,
                  transition: 'all 0.3s ease'
                }}
              >
                <p 
                  style={{
                    fontSize: '16px',
                    color: '#757575',
                    margin: '0 0 12px 0',
                    letterSpacing: '2px'
                  }}
                >
                  {card.label}
                </p>
                <p 
                  style={{
                    fontSize: '36px',
                    fontWeight: 'bold',
                    color: '#2E7D32',
                    margin: 0
                  }}
                >
                  {card.value}
                </p>
              </div>
            );
          })}
        </div>
        
        {/* 底部装饰 */}
        <div 
          style={{
            marginTop: '60px',
            width: '200px',
            height: '4px',
            background: 'linear-gradient(90deg, transparent, #2E7D32, transparent)',
            borderRadius: '2px'
          }}
        />
      </div>
    </AbsoluteFill>
  );
};
