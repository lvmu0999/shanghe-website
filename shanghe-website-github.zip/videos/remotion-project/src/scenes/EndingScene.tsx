import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';

interface EndingSceneProps {
  companyName: string;
  phone: string;
  address: string;
  website: string;
}

export const EndingScene: React.FC<EndingSceneProps> = (props) => {
  const frame = useCurrentFrame();
  
  // 背景淡入
  const bgOpacity = interpolate(frame, [0, 30], [0, 1], {extrapolateRight: 'clamp'});
  
  // LOGO 动画
  const logoScale = interpolate(frame, [0, 45], [0.5, 1], {
    extrapolateRight: 'clamp',
    easing: 'ease-out'
  });
  
  // 文字淡入
  const textOpacity = interpolate(frame, [30, 60], [0, 1], {extrapolateRight: 'clamp'});
  const textY = interpolate(frame, [30, 60], [30, 0], {
    extrapolateRight: 'clamp',
    easing: 'ease-out'
  });
  
  // 联系方式依次出现
  const contactItems = [
    {label: '电话', value: props.phone, delay: 60},
    {label: '地址', value: props.address, delay: 75},
    {label: '官网', value: props.website, delay: 90}
  ];

  return (
    <AbsoluteFill>
      {/* 背景渐变 */}
      <div 
        style={{
          width: '100%',
          height: '100%',
          background: 'linear-gradient(135deg, #2E7D32 0%, #388E3C 50%, #4CAF50 100%)',
          opacity: bgOpacity
        }}
      />
      
      {/* 装饰光晕 */}
      <div 
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '800px',
          height: '800px',
          background: 'radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%)',
          borderRadius: '50%',
          filter: 'blur(60px)'
        }}
      />
      
      {/* 内容 */}
      <div 
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          opacity: textOpacity,
          transform: `translateY(${textY}px)`
        }}
      >
        {/* LOGO */}
        <div 
          style={{
            marginBottom: '40px',
            transform: `scale(${logoScale})`
          }}
        >
          <svg 
            viewBox="0 0 100 100" 
            width="120" 
            height="120"
            style={{
              filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.3))'
            }}
          >
            <circle cx="50" cy="50" r="48" fill="white" opacity="0.2"/>
            <circle cx="50" cy="50" r="45" fill="white" opacity="0.3"/>
            <path 
              d="M50 20 L60 45 L85 45 L65 60 L75 85 L50 70 L25 85 L35 60 L15 45 L40 45 Z" 
              fill="white"
            />
          </svg>
        </div>
        
        {/* 公司名称 */}
        <h1 
          style={{
            fontSize: '48px',
            fontWeight: 'bold',
            color: 'white',
            margin: '0 0 16px 0',
            letterSpacing: '6px',
            textShadow: '0 2px 8px rgba(0,0,0,0.3)'
          }}
        >
          {props.companyName}
        </h1>
        
        {/* 标语 */}
        <p 
          style={{
            fontSize: '24px',
            color: 'rgba(255,255,255,0.9)',
            margin: '0 0 60px 0',
            letterSpacing: '3px',
            fontWeight: '300'
          }}
        >
          发展生态农业，建设美丽乡村
        </p>
        
        {/* 联系方式 */}
        <div 
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '20px',
            alignItems: 'center'
          }}
        >
          {contactItems.map((item, index) => {
            const opacity = interpolate(
              frame,
              [item.delay, item.delay + 30],
              [0, 1],
              {extrapolateRight: 'clamp'}
            );
            const y = interpolate(
              frame,
              [item.delay, item.delay + 30],
              [20, 0],
              {extrapolateRight: 'clamp'}
            );
            
            return (
              <div
                key={index}
                style={{
                  opacity,
                  transform: `translateY(${y}px)`,
                  transition: 'all 0.5s ease'
                }}
              >
                <p 
                  style={{
                    fontSize: '18px',
                    color: 'rgba(255,255,255,0.9)',
                    margin: '8px 0',
                    letterSpacing: '1px'
                  }}
                >
                  <span style={{fontWeight: 'bold', marginRight: '8px'}}>{item.label}：</span>
                  {item.value}
                </p>
              </div>
            );
          })}
        </div>
        
        {/* 底部装饰线 */}
        <div 
          style={{
            marginTop: '60px',
            width: '300px',
            height: '2px',
            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.8), transparent)'
          }}
        />
      </div>
    </AbsoluteFill>
  );
};
