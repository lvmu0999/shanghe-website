import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';

export const SmartFarmScene: React.FC = () => {
  const frame = useCurrentFrame();
  
  // 功能特性
  const features = [
    {
      icon: '📡',
      title: '物联网监测',
      desc: '实时监测土壤、气象、作物生长',
      delay: 0
    },
    {
      icon: '📊',
      title: '大数据分析',
      desc: '海量农业数据智能分析',
      delay: 15
    },
    {
      icon: '🤖',
      title: '智能决策',
      desc: 'AI 驱动科学种植决策',
      delay: 30
    },
    {
      icon: '📈',
      title: '效率提升 30%+',
      desc: '生产效率显著提高',
      delay: 45
    }
  ];

  return (
    <AbsoluteFill>
      {/* 科技蓝背景 */}
      <div 
        style={{
          width: '100%',
          height: '100%',
          background: 'linear-gradient(135deg, #1B5E20 0%, #2E7D32 50%, #388E3C 100%)'
        }}
      />
      
      {/* 网格装饰 */}
      <div 
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
          opacity: 0.5
        }}
      />
      
      {/* 标题 */}
      <div 
        style={{
          position: 'absolute',
          top: '80px',
          left: 0,
          right: 0,
          textAlign: 'center'
        }}
      >
        <h2 
          style={{
            fontSize: '48px',
            fontWeight: 'bold',
            color: 'white',
            margin: '0 0 16px 0',
            letterSpacing: '6px'
          }}
        >
          智慧农业
        </h2>
        <p 
          style={{
            fontSize: '20px',
            color: 'rgba(255,255,255,0.8)',
            margin: 0,
            letterSpacing: '2px'
          }}
        >
          SMART AGRICULTURE
        </p>
      </div>
      
      {/* 中心手机/平板 mockup */}
      <div 
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '600px',
          height: '400px',
          background: 'rgba(255,255,255,0.1)',
          borderRadius: '20px',
          border: '2px solid rgba(255,255,255,0.3)',
          backdropFilter: 'blur(10px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
      >
        <div 
          style={{
            textAlign: 'center',
            color: 'white'
          }}
        >
          <svg 
            viewBox="0 0 100 100" 
            width="120" 
            height="120"
            style={{
              marginBottom: '20px',
              filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.3))'
            }}
          >
            <circle cx="50" cy="50" r="45" fill="none" stroke="white" strokeWidth="2" opacity="0.5"/>
            <circle cx="50" cy="50" r="35" fill="none" stroke="white" strokeWidth="2" opacity="0.7"/>
            <circle cx="50" cy="50" r="25" fill="none" stroke="white" strokeWidth="2"/>
            <circle cx="50" cy="50" r="8" fill="white"/>
            <path 
              d="M50 20 L50 35 M50 65 L50 80 M20 50 L35 50 M65 50 L80 50" 
              stroke="white" 
              strokeWidth="2"
            />
          </svg>
          <p style={{fontSize: '18px', letterSpacing: '2px'}}>智慧农业指挥中心</p>
        </div>
      </div>
      
      {/* 功能特性卡片 */}
      <div 
        style={{
          position: 'absolute',
          top: '220px',
          left: 0,
          right: 0,
          display: 'flex',
          justifyContent: 'center',
          gap: '20px'
        }}
      >
        {features.map((feature, index) => {
          const opacity = interpolate(
            frame,
            [20 + feature.delay, 50 + feature.delay],
            [0, 1],
            {extrapolateRight: 'clamp'}
          );
          const y = interpolate(
            frame,
            [20 + feature.delay, 50 + feature.delay],
            [-30, 0],
            {extrapolateRight: 'clamp'}
          );
          
          return (
            <div
              key={index}
              style={{
                background: 'rgba(255,255,255,0.15)',
                borderRadius: '12px',
                padding: '20px',
                width: '220px',
                textAlign: 'center',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255,255,255,0.2)',
                opacity,
                transform: `translateY(${y}px)`,
                transition: 'all 0.5s ease'
              }}
            >
              <div style={{fontSize: '36px', marginBottom: '12px'}}>{feature.icon}</div>
              <h3 
                style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: 'white',
                  margin: '0 0 8px 0'
                }}
              >
                {feature.title}
              </h3>
              <p 
                style={{
                  fontSize: '13px',
                  color: 'rgba(255,255,255,0.8)',
                  margin: 0
                }}
              >
                {feature.desc}
              </p>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
