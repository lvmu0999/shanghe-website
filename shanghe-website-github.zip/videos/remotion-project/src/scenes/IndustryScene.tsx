import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate, Sequence} from 'remotion';

export const IndustryScene: React.FC = () => {
  const frame = useCurrentFrame();
  
  // 产业板块数据
  const industries = [
    {
      name: '有机种植',
      english: 'ORGANIC PLANTING',
      color: '#4CAF50',
      delay: 0
    },
    {
      name: '生态养殖',
      english: 'ECOLOGICAL BREEDING',
      color: '#66BB6A',
      delay: 15
    },
    {
      name: '农产品加工',
      english: 'AGRICULTURAL PROCESSING',
      color: '#81C784',
      delay: 30
    },
    {
      name: '智慧农业',
      english: 'SMART AGRICULTURE',
      color: '#2E7D32',
      delay: 45
    },
    {
      name: '食品流通',
      english: 'FOOD DISTRIBUTION',
      color: '#A5D6A7',
      delay: 60
    }
  ];

  return (
    <AbsoluteFill style={{background: '#F5F7FA'}}>
      {/* 标题 */}
      <div 
        style={{
          position: 'absolute',
          top: '80px',
          left: 0,
          right: 0,
          textAlign: 'center'
        }}
      >
        <h2 
          style={{
            fontSize: '48px',
            fontWeight: 'bold',
            color: '#2E7D32',
            margin: '0 0 16px 0',
            letterSpacing: '6px'
          }}
        >
          产业布局
        </h2>
        <p 
          style={{
            fontSize: '20px',
            color: '#757575',
            margin: 0,
            letterSpacing: '2px'
          }}
        >
          INDUSTRIAL LAYOUT
        </p>
      </div>
      
      {/* 产业卡片 */}
      <div 
        style={{
          position: 'absolute',
          top: '200px',
          left: 0,
          right: 0,
          bottom: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '30px',
          padding: '0 60px'
        }}
      >
        {industries.map((industry, index) => {
          const opacity = interpolate(
            frame,
            [30 + industry.delay, 60 + industry.delay],
            [0, 1],
            {extrapolateRight: 'clamp'}
          );
          const scaleX = interpolate(
            frame,
            [30 + industry.delay, 70 + industry.delay],
            [0, 1],
            {extrapolateRight: 'clamp'}
          );
          
          return (
            <div
              key={index}
              style={{
                flex: 1,
                maxWidth: '240px',
                height: '400px',
                background: `linear-gradient(135deg, ${industry.color} 0%, ${industry.color}99 100%)`,
                borderRadius: '16px',
                padding: '40px 24px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                opacity,
                transform: `scaleX(${scaleX})`,
                transformOrigin: 'center',
                boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                transition: 'all 0.5s ease'
              }}
            >
              {/* 图标占位 */}
              <div 
                style={{
                  width: '80px',
                  height: '80px',
                  background: 'rgba(255,255,255,0.2)',
                  borderRadius: '50%',
                  marginBottom: '30px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <svg 
                  viewBox="0 0 64 64" 
                  width="48" 
                  height="48"
                  style={{fill: 'white'}}
                >
                  <circle cx="32" cy="32" r="28" fill="white" opacity="0.3"/>
                  <path 
                    d="M32 16 L36 28 L48 28 L38 36 L42 48 L32 40 L22 48 L26 36 L16 28 L28 28 Z" 
                    fill="white"
                  />
                </svg>
              </div>
              
              {/* 中文名称 */}
              <h3 
                style={{
                  fontSize: '28px',
                  fontWeight: 'bold',
                  color: 'white',
                  margin: '0 0 12px 0',
                  letterSpacing: '3px'
                }}
              >
                {industry.name}
              </h3>
              
              {/* 英文名称 */}
              <p 
                style={{
                  fontSize: '14px',
                  color: 'rgba(255,255,255,0.8)',
                  margin: 0,
                  letterSpacing: '1px',
                  textAlign: 'center'
                }}
              >
                {industry.english}
              </p>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
