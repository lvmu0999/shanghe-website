import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';

export const HonorsScene: React.FC = () => {
  const frame = useCurrentFrame();
  
  const honors = [
    {
      title: '农业产业化重点龙头企业',
      level: '国家级',
      delay: 0
    },
    {
      title: '绿色食品认证',
      level: '权威认证',
      delay: 15
    },
    {
      title: '有机产品认证',
      level: '国际认证',
      delay: 30
    },
    {
      title: '科技创新企业',
      level: '省级',
      delay: 45
    }
  ];

  return (
    <AbsoluteFill>
      {/* 金色渐变背景 */}
      <div 
        style={{
          width: '100%',
          height: '100%',
          background: 'linear-gradient(135deg, #FFF8E1 0%, #FFECB3 50%, #FFE082 100%)'
        }}
      />
      
      {/* 标题 */}
      <div 
        style={{
          position: 'absolute',
          top: '80px',
          left: 0,
          right: 0,
          textAlign: 'center'
        }}
      >
        <h2 
          style={{
            fontSize: '48px',
            fontWeight: 'bold',
            color: '#2E7D32',
            margin: '0 0 16px 0',
            letterSpacing: '6px'
          }}
        >
          荣誉资质
        </h2>
        <p 
          style={{
            fontSize: '20px',
            color: '#757575',
            margin: 0,
            letterSpacing: '2px'
          }}
        >
          HONORS & AWARDS
        </p>
      </div>
      
      {/* 荣誉卡片 */}
      <div 
        style={{
          position: 'absolute',
          top: '200px',
          left: 0,
          right: 0,
          bottom: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '40px',
          padding: '0 60px'
        }}
      >
        {honors.map((honor, index) => {
          const opacity = interpolate(
            frame,
            [20 + honor.delay, 50 + honor.delay],
            [0, 1],
            {extrapolateRight: 'clamp'}
          );
          const scale = interpolate(
            frame,
            [20 + honor.delay, 60 + honor.delay],
            [0.8, 1],
            {extrapolateRight: 'clamp'}
          );
          const rotate = interpolate(
            frame,
            [20 + honor.delay, 60 + honor.delay],
            [5, 0],
            {extrapolateRight: 'clamp'}
          );
          
          return (
            <div
              key={index}
              style={{
                background: 'white',
                borderRadius: '16px',
                padding: '40px 30px',
                width: '260px',
                textAlign: 'center',
                boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
                opacity,
                transform: `scale(${scale}) rotate(${rotate}deg)`,
                transition: 'all 0.5s ease',
                border: '2px solid #FFD700'
              }}
            >
              {/* 奖牌图标 */}
              <div 
                style={{
                  width: '80px',
                  height: '80px',
                  margin: '0 auto 24px',
                  background: 'linear-gradient(135deg, #FFD700 0%, #FFA000 100%)',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 4px 12px rgba(255,215,0,0.4)'
                }}
              >
                <svg 
                  viewBox="0 0 64 64" 
                  width="48" 
                  height="48"
                  style={{fill: 'white'}}
                >
                  <path d="M32 8 L36 24 L52 24 L40 36 L44 52 L32 42 L20 52 L24 36 L12 24 L28 24 Z"/>
                </svg>
              </div>
              
              {/* 荣誉级别 */}
              <p 
                style={{
                  fontSize: '14px',
                  color: '#FFA000',
                  fontWeight: 'bold',
                  margin: '0 0 12px 0',
                  letterSpacing: '1px'
                }}
              >
                {honor.level}
              </p>
              
              {/* 荣誉名称 */}
              <h3 
                style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: '#333',
                  margin: 0,
                  lineHeight: 1.5
                }}
              >
                {honor.title}
              </h3>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
