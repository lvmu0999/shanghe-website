# 新疆上禾生态农业发展有限公司官网

这是一个现代化的企业官网，参考海大集团网站设计，为新疆上禾生态农业发展有限公司打造。

## 网站结构

```
shanghe-website/
├── index.html          # 首页
├── css/
│   ├── style.css       # 主样式文件
│   ├── responsive.css  # 响应式样式
│   └── pages.css       # 内页样式
├── js/
│   └── main.js         # JavaScript 交互
├── images/             # 图片资源目录
└── pages/
    ├── about.html      # 关于上禾
    ├── industry.html   # 产业布局
    ├── technology.html # 科技研发
    ├── news.html       # 新闻动态
    ├── investor.html   # 投资者关系
    └── careers.html    # 人才中心
```

## 功能特点

- ✅ 响应式设计，适配 PC、平板、手机
- ✅ 现代化 UI 设计，绿色农业主题
- ✅ 轮播图动画效果
- ✅ 数字滚动动画
- ✅ 平滑滚动导航
- ✅ 移动端菜单
- ✅ SEO 友好结构

## 本地预览

直接在浏览器中打开 `index.html` 即可预览网站。

或使用本地服务器：

```bash
# 使用 Python
cd shanghe-website
python -m http.server 8080

# 或使用 Node.js
npx serve .
```

然后访问 http://localhost:8080

## 部署到 GitHub Pages

### 方法一：使用 GitHub 网页界面

1. 登录 GitHub，创建新仓库（如 `shanghe-agri-website`）
2. 将此文件夹的所有内容上传到仓库
3. 进入仓库 Settings → Pages
4. 在 Source 下选择 `main` 分支，文件夹选择 `/ (root)`
5. 点击 Save，等待几分钟
6. 访问 `https://你的用户名.github.io/shanghe-agri-website/`

### 方法二：使用 Git 命令行

```bash
cd shanghe-website

# 初始化 Git 仓库
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit - 上禾农业官网"

# 添加远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/你的用户名/shanghe-agri-website.git

# 推送到 main 分支
git branch -M main
git push -u origin main
```

然后在 GitHub 仓库设置中启用 Pages。

## 部署到国内平台

### 码云 Gitee Pages

1. 注册码云账号 (gitee.com)
2. 创建新仓库
3. 推送代码到码云
4. 进入仓库 → 管理 → Gitee Pages
5. 选择分支，启动服务

### Vercel

1. 注册 Vercel (vercel.com)
2. 导入 GitHub 仓库
3. 自动部署，获得域名

## 自定义内容

### 修改公司信息

编辑各个 HTML 文件中的以下内容：
- 公司名称
- 联系电话
- 邮箱地址
- 公司地址
- ICP 备案号

### 替换图片

将实际图片放入 `images/` 目录，然后修改 HTML 中的占位符为实际图片路径。

### 修改配色

编辑 `css/style.css` 中的 CSS 变量：

```css
:root {
    --primary-color: #2E7D32;    /* 主色调 */
    --primary-light: #81C784;    /* 浅色 */
    --primary-dark: #1B5E20;     /* 深色 */
    --secondary-color: #FF9800;  /* 辅助色 */
}
```

## 浏览器支持

- Chrome (推荐)
- Firefox
- Safari
- Edge
- 微信浏览器

## 技术栈

- HTML5
- CSS3 (Flexbox, Grid)
- Vanilla JavaScript (ES6+)
- SVG 图标

## 许可证

MIT License

---

**创建时间**: 2026-03-23  
**设计参考**: 海大集团 (www.haid.com.cn)
