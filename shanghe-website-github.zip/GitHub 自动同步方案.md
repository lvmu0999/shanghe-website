# 🔄 GitHub 自动同步方案

**创建时间**: 2026 年 3 月 24 日 00:06  
**目标**: 自动同步上禾网站到 GitHub

---

## ⚠️ 当前状态

### 认证情况
- **GitHub CLI**: ❌ 未认证
- **SSH 密钥**: ❌ 连接失败
- **HTTPS**: ❌ 需要交互式认证
- **Personal Access Token**: ❌ 未配置

### 远程仓库配置
- **github**: git@github.com:lvmu0999/shanghe-agri-website.git
- **github-https**: https://github.com/lvmu0999/shanghe-website.git
- **origin**: git@gitee.com:lvmu0999/shanghe-agri-website.git ✅

### 本地状态
- **最新提交**: a7b43b4 添加 GitHub 同步指南和完成报告
- **Gitee 状态**: ✅ 已推送
- **GitHub 状态**: ⏳ 待推送

---

## 🔧 自动同步方案

### 方案一：使用 GitHub Actions（推荐）⭐

**原理**: 在 Gitee 推送后，触发 GitHub Actions 自动同步

#### 步骤 1: 在 GitHub 仓库创建 Actions 工作流

创建 `.github/workflows/sync-from-gitee.yml`:

```yaml
name: Sync from Gitee

on:
  workflow_dispatch:  # 手动触发
  schedule:
    - cron: '0 */6 * * *'  # 每 6 小时同步一次

jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout GitHub repo
        uses: actions/checkout@v3
        with:
          fetch-depth: 0
          repository: lvmu0999/shanghe-website
          token: ${{ secrets.GITHUB_TOKEN }}

      - name: Add Gitee remote
        run: |
          git remote add gitee https://gitee.com/lvmu0999/shanghe-agri-website.git
          
      - name: Fetch from Gitee
        run: |
          git fetch gitee master
          
      - name: Merge from Gitee
        run: |
          git config user.name "GitHub Actions"
          git config user.email "actions@github.com"
          git merge gitee/master --allow-unrelated-histories -m "Sync from Gitee" || true
          
      - name: Push to GitHub
        run: |
          git push origin master
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

#### 步骤 2: 手动触发同步

1. 访问：https://github.com/lvmu0999/shanghe-website/actions
2. 选择 "Sync from Gitee" 工作流
3. 点击 "Run workflow"
4. 等待同步完成

---

### 方案二：使用镜像仓库功能

**原理**: GitHub 仓库镜像 Gitee 仓库

#### 步骤

1. 访问：https://github.com/lvmu0999/shanghe-website/settings
2. 寻找 "Import repository" 或 "Mirroring" 选项
3. 输入 Gitee 仓库 URL:
   ```
   https://gitee.com/lvmu0999/shanghe-agri-website.git
   ```
4. 启用自动同步

**注意**: GitHub 原生不支持自动镜像，需要使用第三方工具。

---

### 方案三：使用第三方同步服务

#### 选项 A: GitMirrors

1. 访问：https://gitmirrors.com/
2. 添加 Gitee 仓库作为源
3. 添加 GitHub 仓库作为目标
4. 配置自动同步

#### 选项 B: Self-hosted Sync

使用服务器定时任务同步：

```bash
# /etc/cron.d/github-sync
0 */6 * * * root /home/admin/openclaw/workspace/github-push.sh >> /var/log/github-sync.log 2>&1
```

---

### 方案四：一次性手动推送（最快）

#### 在本地电脑执行：

```bash
# 1. 克隆 Gitee 仓库
git clone git@gitee.com:lvmu0999/shanghe-agri-website.git
cd shanghe-agri-website

# 2. 添加 GitHub 远程
git remote add github https://github.com/lvmu0999/shanghe-website.git

# 3. 推送到 GitHub
git push github master
```

---

## 📊 推荐方案

### 最佳实践：方案一 + 方案四

1. **立即同步**: 使用方案四（手动推送一次）
2. **持续同步**: 配置方案一（GitHub Actions 定时同步）

### 理由

- **方案四**: 快速完成首次同步（5 分钟）
- **方案一**: 后续自动同步，无需手动操作

---

## 🚀 执行方案四（手动推送）

### 在 Windows/Mac 本地执行

```powershell
# Windows PowerShell
# 1. 克隆 Gitee 仓库
git clone git@gitee.com:lvmu0999/shanghe-agri-website.git
cd shanghe-agri-website

# 2. 添加 GitHub 远程
git remote add github https://github.com/lvmu0999/shanghe-website.git

# 3. 推送到 GitHub
git push github master

# 4. 设置上游分支
git push github master -u
```

### 预计输出

```bash
Enumerating objects: 101, done.
Counting objects: 100% (101/101), done.
Delta compression using up to 4 threads
Compressing objects: 100% (95/95), done.
Writing objects: 100% (101/101), 1.2 MiB | 2.5 MiB/s, done.
Total 101 (delta 12), reused 0 (delta 0), pack-reused 0
remote: Resolving deltas: 100% (12/12)
remote: 
remote: Create a pull request for 'master' on the GitHub web.
remote: 
remote: 
remote: GitHub found 1 vulnerability on lvmu0999/shanghe-website's default branch (1).
remote: 
remote: 
To https://github.com/lvmu0999/shanghe-website.git
 * [new branch]      master -> master
Branch 'master' set up to track remote branch 'master' from 'github'.
```

---

## ✅ 同步后检查

### 检查 GitHub 仓库

1. 访问：https://github.com/lvmu0999/shanghe-website
2. 确认文件完整（101+ 文件）
3. 确认提交历史（7 次提交）

### 启用 GitHub Pages

1. Settings → Pages
2. Source: Deploy from a branch
3. Branch: master / root
4. Save

**GitHub Pages 地址**:
```
https://lvmu0999.github.io/shanghe-website/
```

---

## 📈 自动同步配置（GitHub Actions）

### 创建 Actions 工作流

**文件**: `.github/workflows/auto-sync.yml`

```yaml
name: Auto Sync from Gitee

on:
  workflow_dispatch:
  schedule:
    - cron: '0 0 * * *'  # 每天午夜同步

jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
        with:
          fetch-depth: 0
          
      - name: Add Gitee remote
        run: |
          git remote add gitee https://gitee.com/lvmu0999/shanghe-agri-website.git
          
      - name: Fetch and merge
        run: |
          git fetch gitee master
          git merge gitee/master --allow-unrelated-histories -m "Auto sync from Gitee" || true
          
      - name: Push updates
        run: |
          git push origin master
```

---

## 📞 联系信息

### GitHub 账号
- **用户名**: lvmu0999
- **邮箱**: 1131680431@qq.com

### 仓库信息
- **Gitee**: https://gitee.com/lvmu0999/shanghe-agri-website ✅
- **GitHub**: https://github.com/lvmu0999/shanghe-website ⏳

---

## 🎯 下一步

### 立即执行（5 分钟）
- [ ] 在本地电脑克隆 Gitee 仓库
- [ ] 添加 GitHub 远程
- [ ] 推送到 GitHub
- [ ] 启用 GitHub Pages

### 后续配置（10 分钟）
- [ ] 创建 GitHub Actions 工作流
- [ ] 测试手动触发同步
- [ ] 配置定时同步（可选）

---

**文档生成时间**: 2026 年 3 月 24 日 00:06  
**推荐方案**: 先手动推送一次，再配置 GitHub Actions 自动同步
