# 部署到码云 Gitee Pages - 完整指南

## 第一步：注册/登录码云

1. 访问 https://gitee.com
2. 如果没有账号，先注册（支持手机号注册）
3. 登录你的账号

## 第二步：创建仓库

### 方式 A：网页创建（推荐）

1. 访问 https://gitee.com/new
2. 填写仓库信息：
   - **仓库名称**: `shanghe-agri-website`
   - **仓库介绍**: 新疆上禾生态农业发展有限公司官网
   - **仓库首页**: 勾选「使用 README.md 初始化仓库」❌ **不要勾选**（我们已有代码）
   - **许可证**: 选择「MIT」
   - **公开度**: 选择「公开」
3. 点击「创建」

### 方式 B：使用 Git 命令

```bash
cd /home/admin/openclaw/workspace/shanghe-website

# 添加 Gitee 远程仓库（替换为你的 Gitee 用户名）
git remote add origin git@gitee.com:你的用户名/shanghe-agri-website.git

# 或者使用 HTTPS
git remote add origin https://gitee.com/你的用户名/shanghe-agri-website.git
```

## 第三步：推送代码到 Gitee

### 使用 HTTPS（需要输入密码）

```bash
cd /home/admin/openclaw/workspace/shanghe-website

# 推送代码
git push -u origin master
```

### 使用 SSH（推荐，无需每次输入密码）

1. **生成 SSH 密钥**（如果已有可跳过）：
```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
# 一直按回车即可
```

2. **查看公钥**：
```bash
cat ~/.ssh/id_ed25519.pub
```

3. **添加 SSH 公钥到 Gitee**：
   - 复制上面的公钥内容
   - 访问 https://gitee.com/profile/sshkeys
   - 点击「添加公钥」
   - 粘贴公钥，填写标题，点击确定

4. **测试 SSH 连接**：
```bash
ssh -T git@gitee.com
```

5. **推送代码**：
```bash
cd /home/admin/openclaw/workspace/shanghe-website
git push -u origin master
```

## 第四步：启用 Gitee Pages 服务

1. 进入你的仓库页面：https://gitee.com/你的用户名/shanghe-agri-website
2. 点击顶部菜单的「**管理**」
3. 左侧菜单找到「**Gitee Pages**」
4. 配置 Pages 服务：
   - **来源分支**: 选择 `master`
   - **站点目录**: 选择 `/`（根目录）
   - **强制 HTTPS**: 勾选
5. 点击「**启动**」按钮
6. 等待约 1-2 分钟，页面会显示：
   - **访问地址**: https://你的用户名.gitee.io/shanghe-agri-website/

## 第五步：自定义域名（可选）

如果你有域名，可以绑定自定义域名：

1. 在 Gitee Pages 页面找到「自定义域名」
2. 输入你的域名，如 `www.shanghe-agri.com`
3. 在你的域名 DNS 服务商处添加 CNAME 记录：
   ```
   类型：CNAME
   主机：www
   值：你的用户名.gitee.io
   ```
4. 等待 DNS 生效（通常几分钟到几小时）

## 第六步：更新网站

后续修改网站后，只需推送更新：

```bash
cd /home/admin/openclaw/workspace/shanghe-website

# 提交更改
git add .
git commit -m "更新网站内容"

# 推送到 Gitee
git push
```

Gitee Pages 会自动重新部署，通常 1-2 分钟后生效。

---

## 常见问题

### Q: 推送时提示权限错误？
A: 确保你已添加 SSH 公钥到 Gitee，或使用 HTTPS 方式并输入正确的密码。

### Q: Pages 服务启动失败？
A: 检查仓库是否为公开仓库，私有仓库需要 Gitee 会员才能使用 Pages。

### Q: 访问速度慢？
A: Gitee Pages 在国内访问速度很快，如果慢可能是首次加载，刷新即可。

### Q: 如何删除/重新部署？
A: 在 Gitee Pages 页面点击「停止」，然后重新「启动」即可。

---

## 快速命令汇总

```bash
# 进入网站目录
cd /home/admin/openclaw/workspace/shanghe-website

# 查看远程仓库
git remote -v

# 添加远程仓库（替换为你的 Gitee 用户名）
git remote add origin git@gitee.com:你的用户名/shanghe-agri-website.git

# 推送代码
git push -u origin master

# 后续更新
git add .
git commit -m "更新说明"
git push
```

---

**创建时间**: 2026-03-23  
**网站目录**: /home/admin/openclaw/workspace/shanghe-website/
