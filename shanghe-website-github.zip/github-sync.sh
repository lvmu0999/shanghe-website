#!/bin/bash
# GitHub 仓库创建和推送脚本
# 使用方法：在本地电脑（Windows/Mac）运行此脚本

set -e

echo "=========================================="
echo "🚀 上禾网站 GitHub 自动同步脚本"
echo "=========================================="
echo ""

# 配置
GITEE_REPO="git@gitee.com:lvmu0999/shanghe-agri-website.git"
GITHUB_REPO="https://github.com/lvmu0999/shanghe-website.git"
LOCAL_DIR="shanghe-website-temp"

# 检查 Git 是否安装
if ! command -v git &> /dev/null; then
    echo "❌ Git 未安装，请先安装 Git"
    exit 1
fi

echo "✅ Git 已安装：$(git --version)"
echo ""

# 检查是否已有 GitHub CLI
if command -v gh &> /dev/null; then
    echo "✅ GitHub CLI 已安装"
    echo ""
    
    # 检查是否已认证
    if gh auth status 2>&1 | grep -q "Logged in"; then
        echo "✅ GitHub 已认证"
        echo ""
        
        # 检查仓库是否存在
        if gh repo view lvmu0999/shanghe-website &> /dev/null; then
            echo "✅ GitHub 仓库已存在"
        else
            echo "📦 创建 GitHub 仓库..."
            gh repo create lvmu0999/shanghe-website --public --confirm
            echo "✅ GitHub 仓库创建完成"
        fi
        echo ""
    else
        echo "⚠️ GitHub 未认证"
        echo "请先运行：gh auth login"
        echo ""
        read -p "是否现在进行认证？(y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            gh auth login
        else
            echo "❌ 需要认证才能继续"
            exit 1
        fi
    fi
else
    echo "⚠️ GitHub CLI 未安装，将使用 HTTPS 方式推送"
    echo "安装 GitHub CLI 可获得更好体验：https://cli.github.com/"
    echo ""
fi

# 克隆 Gitee 仓库
echo "📥 从 Gitee 克隆仓库..."
if [ -d "$LOCAL_DIR" ]; then
    echo "⚠️ 目录 $LOCAL_DIR 已存在，删除中..."
    rm -rf "$LOCAL_DIR"
fi

git clone "$GITEE_REPO" "$LOCAL_DIR"
cd "$LOCAL_DIR"

echo "✅ 克隆完成"
echo ""

# 添加 GitHub 远程
echo "🔗 添加 GitHub 远程仓库..."
if git remote | grep -q "github"; then
    echo "⚠️ GitHub 远程已存在，更新中..."
    git remote set-url github "$GITHUB_REPO"
else
    git remote add github "$GITHUB_REPO"
fi
echo "✅ GitHub 远程添加完成"
echo ""

# 推送到 GitHub
echo "📤 推送到 GitHub..."
git push github master

echo ""
echo "✅ 推送完成！"
echo ""

# 显示结果
echo "=========================================="
echo "🎉 GitHub 同步完成！"
echo "=========================================="
echo ""
echo "📦 GitHub 仓库：https://github.com/lvmu0999/shanghe-website"
echo "🌐 GitHub Pages: https://lvmu0999.github.io/shanghe-website/"
echo ""
echo "下一步操作："
echo "1. 访问 GitHub 仓库查看代码"
echo "2. 启用 GitHub Pages（Settings → Pages）"
echo "3. 启用 GitHub Actions（Actions 标签页）"
echo ""

# 清理
cd ..
rm -rf "$LOCAL_DIR"
echo "✅ 临时文件已清理"
