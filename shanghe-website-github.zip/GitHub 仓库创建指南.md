# 🚀 上禾网站 GitHub 仓库创建指南

**创建时间**: 2026 年 3 月 24 日 00:20  
**目标**: 创建 GitHub 仓库并启用 Actions 自动同步

---

## 📋 方案选择

### 方案 A: 使用自动化脚本（推荐）⭐

**适用**: Windows/Mac 本地电脑

**步骤**:

#### 1️⃣ 下载同步脚本

脚本位置：`github-sync.sh`

#### 2️⃣ 在本地电脑运行脚本

**Mac/Linux**:
```bash
chmod +x github-sync.sh
./github-sync.sh
```

**Windows (Git Bash)**:
```bash
bash github-sync.sh
```

#### 3️⃣ 按提示操作

脚本会自动：
- ✅ 从 Gitee 克隆代码
- ✅ 添加 GitHub 远程
- ✅ 推送到 GitHub
- ✅ 清理临时文件

---

### 方案 B: 手动操作（无需脚本）

**步骤**:

#### 1️⃣ 创建 GitHub 仓库

1. 访问：https://github.com/new
2. **Repository name**: `shanghe-website`
3. **Visibility**: ✅ Public
4. **不要勾选**:
   - ❌ Add a README file
   - ❌ Add .gitignore
   - ❌ Choose a license
5. 点击 **"Create repository"**

#### 2️⃣ 从 Gitee 克隆并推送

**Windows PowerShell**:
```powershell
# 1. 克隆 Gitee 仓库
git clone git@gitee.com:lvmu0999/shanghe-agri-website.git
cd shanghe-agri-website

# 2. 添加 GitHub 远程
git remote add github https://github.com/lvmu0999/shanghe-website.git

# 3. 推送到 GitHub
git push github master

# 4. 设置上游分支（可选）
git push github master -u
```

**Mac/Linux Terminal**:
```bash
# 操作相同
git clone git@gitee.com:lvmu0999/shanghe-agri-website.git
cd shanghe-agri-website
git remote add github https://github.com/lvmu0999/shanghe-website.git
git push github master
```

#### 3️⃣ 验证推送

访问：https://github.com/lvmu0999/shanghe-website

应该看到：
- ✅ 所有文件（102+ 文件）
- ✅ 提交历史（11 次提交）
- ✅ 版本演进报告

---

### 方案 C: 使用 GitHub CLI（最简洁）

**前提**: 已安装 GitHub CLI

#### 1️⃣ 安装 GitHub CLI

**Mac**:
```bash
brew install gh
```

**Windows**:
```powershell
winget install GitHub.cli
```

**Linux**:
```bash
sudo apt install gh  # Debian/Ubuntu
sudo dnf install gh  # Fedora
```

#### 2️⃣ 认证 GitHub

```bash
gh auth login
```

按提示：
1. 选择 **GitHub.com**
2. 选择 **HTTPS**
3. 选择 **Yes** 登录
4. 复制代码并在浏览器中授权

#### 3️⃣ 创建仓库并推送

```bash
# 1. 克隆 Gitee 仓库
git clone git@gitee.com:lvmu0999/shanghe-agri-website.git
cd shanghe-agri-website

# 2. 创建 GitHub 仓库
gh repo create lvmu0999/shanghe-website --public --source=. --remote=github --push
```

完成！🎉

---

## ⚙️ 启用 GitHub Actions

推送完成后，启用自动同步：

### 步骤 1: 访问 Actions 页面

访问：https://github.com/lvmu0999/shanghe-website/actions

### 步骤 2: 启用工作流

如果是首次使用，会看到提示：

> "I understand my workflows, go ahead and enable them"

点击绿色按钮 **"Enable workflows"**

### 步骤 3: 验证工作流

应该看到：
- ✅ **Auto Sync from Gitee** 工作流
- ✅ 状态：Enabled
- ✅ 触发条件：每天 UTC 0 点（北京时间 8 点）

### 步骤 4: 手动触发同步（可选）

1. 点击工作流名称 **"Auto Sync from Gitee"**
2. 点击 **"Run workflow"** 按钮
3. 选择 **master** 分支
4. 点击 **"Run workflow"**
5. 等待 1-2 分钟完成

---

## 🌐 启用 GitHub Pages

### 步骤 1: 访问 Pages 设置

访问：https://github.com/lvmu0999/shanghe-website/settings/pages

### 步骤 2: 配置 Pages

**Build and deployment**:
- **Source**: Deploy from a branch
- **Branch**: master → /(root)
- 点击 **Save**

### 步骤 3: 等待部署

约 1-2 分钟后，页面会显示：

> "Your site is live at https://lvmu0999.github.io/shanghe-website/"

### 步骤 4: 验证访问

访问：https://lvmu0999.github.io/shanghe-website/

应该看到：
- ✅ 网站首页
- ✅ 多语言切换功能
- ✅ 所有页面正常

---

## ✅ 检查清单

### GitHub 仓库创建
- [ ] GitHub 仓库已创建
- [ ] 代码已推送（11 次提交）
- [ ] 文件完整（102+ 文件）
- [ ] 提交历史正确

### GitHub Actions
- [ ] Actions 已启用
- [ ] 工作流可见
- [ ] 手动触发测试成功

### GitHub Pages
- [ ] Pages 已启用
- [ ] 部署成功
- [ ] 网站可访问

### 验证项目
- [ ] 首页正常显示
- [ ] 多语言切换正常
- [ ] 所有链接有效
- [ ] 移动端适配正常

---

## 🔧 常见问题

### Q1: 推送时提示认证失败

**解决方案**:

#### 方式 1: 使用 Personal Access Token

1. 访问：https://github.com/settings/tokens
2. 点击 **"Generate new token (classic)"**
3. **Note**: `shanghe-website-deploy`
4. **Expiration**: `No expiration`
5. **Select scopes**: ✅ `repo` (Full control of private repositories)
6. 点击 **"Generate token"**
7. **复制 Token**（只显示一次！）
8. 推送时使用 Token 作为密码：
   ```bash
   git push github master
   # Username: lvmu0999
   # Password: [粘贴 Token]
   ```

#### 方式 2: 使用 SSH

```bash
# 1. 生成 SSH 密钥（如果没有）
ssh-keygen -t ed25519 -C "1131680431@qq.com"

# 2. 添加公钥到 GitHub
# 访问：https://github.com/settings/keys
# 点击 "New SSH key"
# 粘贴 ~/.ssh/id_ed25519.pub 内容

# 3. 更改远程 URL
git remote set-url github git@github.com:lvmu0999/shanghe-website.git

# 4. 推送
git push github master
```

### Q2: GitHub CLI 认证失败

**解决方案**:
```bash
# 重新认证
gh auth logout
gh auth login

# 如果还是失败，使用 HTTPS + Token 方式
```

### Q3: Actions 工作流没有触发

**解决方案**:
1. 检查是否已启用工作流
2. 手动触发一次：点击 "Run workflow"
3. 检查 Actions 日志

### Q4: Pages 部署失败

**解决方案**:
1. 检查是否有 `index.html` 在根目录
2. 检查 Branch 设置是否正确（master / root）
3. 查看 Pages 部署日志

---

## 📊 预期结果

### GitHub 仓库内容

```
shanghe-website/
├── .github/
│   └── workflows/
│       └── auto-sync.yml    # Actions 工作流
├── index.html               # 首页
├── css/
│   ├── style.css
│   ├── responsive.css
│   └── pages.css
├── js/
│   ├── main.js
│   ├── i18n.js
│   └── news-data.js
├── pages/
│   ├── about.html
│   ├── industry.html
│   ├── technology.html
│   ├── news.html
│   ├── investor.html
│   ├── careers.html
│   └── contact.html
├── images/
├── videos/
├── miniprogram/
└── [19 个开发文档]
```

### 在线访问地址

| 平台 | 地址 | 状态 |
|------|------|------|
| GitHub | https://github.com/lvmu0999/shanghe-website | ⏳ 待创建 |
| GitHub Pages | https://lvmu0999.github.io/shanghe-website/ | ⏳ 待启用 |
| Gitee | https://gitee.com/lvmu0999/shanghe-agri-website | ✅ 已推送 |
| Cloudflare Pages | https://master.shanghe-agri-website.pages.dev | ✅ 已上线 |

---

## 🎯 快速操作（5 分钟完成）

### Windows 用户

```powershell
# 1. 打开 PowerShell
# 2. 执行以下命令

git clone git@gitee.com:lvmu0999/shanghe-agri-website.git
cd shanghe-agri-website
git remote add github https://github.com/lvmu0999/shanghe-website.git
git push github master
```

### Mac 用户

```bash
# 1. 打开 Terminal
# 2. 执行以下命令

git clone git@gitee.com:lvmu0999/shanghe-agri-website.git
cd shanghe-agri-website
git remote add github https://github.com/lvmu0999/shanghe-website.git
git push github master
```

### 使用 GitHub CLI（推荐）

```bash
# 1. 安装 gh（如果未安装）
# Mac: brew install gh
# Windows: winget install GitHub.cli

# 2. 认证
gh auth login

# 3. 克隆并推送
git clone git@gitee.com:lvmu0999/shanghe-agri-website.git
cd shanghe-agri-website
gh repo create lvmu0999/shanghe-website --public --source=. --remote=github --push
```

---

## 📞 联系信息

### GitHub 账号
- **用户名**: lvmu0999
- **邮箱**: 1131680431@qq.com

### 项目信息
- **企业**: 新疆上禾智慧农业发展有限责任公司
- **网站版本**: v9.0
- **小程序版本**: v1.0
- **支持语言**: 4 种（中文/英文/俄文/哈萨克文）

---

## 🎉 完成后的效果

### GitHub 仓库
- ✅ 102+ 文件
- ✅ 11 次提交历史
- ✅ 完整的开发文档
- ✅ Actions 自动同步

### GitHub Pages
- ✅ 自动 HTTPS
- ✅ 全球 CDN 加速
- ✅ 自定义域名支持
- ✅ 自动部署

### 自动同步
- ✅ 每天自动同步 Gitee → GitHub
- ✅ 支持手动触发
- ✅ 智能检测变更

---

**指南生成时间**: 2026 年 3 月 24 日 00:20  
**下一步**: 选择方案 A/B/C 创建 GitHub 仓库并启用 Actions
