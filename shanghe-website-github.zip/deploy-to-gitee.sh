#!/bin/bash

# 上禾农业官网 - Gitee 部署脚本
# 使用方法：./deploy-to-gitee.sh 你的 Gitee 用户名

set -e

GITEE_USER=$1

if [ -z "$GITEE_USER" ]; then
    echo "❌ 请提供 Gitee 用户名"
    echo "用法：./deploy-to-gitee.sh 你的用户名"
    echo "例如：./deploy-to-gitee.sh zhangsan"
    exit 1
fi

REPO_NAME="shanghe-agri-website"
REMOTE_URL="git@gitee.com:${GITEE_USER}/${REPO_NAME}.git"

echo "🚀 开始部署到 Gitee Pages"
echo "================================"
echo "📁 仓库名称：${REPO_NAME}"
echo "👤 Gitee 用户：${GITEE_USER}"
echo "🔗 远程地址：${REMOTE_URL}"
echo "================================"
echo ""

# 检查 SSH 密钥
if [ ! -f ~/.ssh/id_ed25519.pub ]; then
    echo "❌ 未找到 SSH 公钥，请先生成 SSH 密钥"
    echo "运行：ssh-keygen -t ed25519 -C \"your_email@example.com\""
    exit 1
fi

echo "✅ SSH 密钥已存在"
echo ""
echo "📋 你的 SSH 公钥："
echo "--------------------------------"
cat ~/.ssh/id_ed25519.pub
echo "--------------------------------"
echo ""
echo "⚠️  请先将此公钥添加到 Gitee："
echo "   1. 访问 https://gitee.com/profile/sshkeys"
echo "   2. 点击「添加公钥」"
echo "   3. 粘贴上面的公钥内容"
echo ""
read -p "按回车键继续..."

# 检查远程仓库
if git remote | grep -q "origin"; then
    echo "⚠️  已存在 remote origin，是否覆盖？(y/n)"
    read -p "> " confirm
    if [ "$confirm" != "y" ]; then
        echo "❌ 取消部署"
        exit 1
    fi
    git remote remove origin
fi

# 添加远程仓库
echo "🔗 添加远程仓库..."
git remote add origin $REMOTE_URL
echo "✅ 远程仓库添加成功"
echo ""

# 推送代码
echo "📤 推送代码到 Gitee..."
git push -u origin master
echo ""
echo "✅ 代码推送成功！"
echo ""
echo "================================"
echo "🎉 部署完成！"
echo "================================"
echo ""
echo "📝 下一步操作："
echo "   1. 访问 https://gitee.com/${GITEE_USER}/${REPO_NAME}"
echo "   2. 点击「管理」→「Gitee Pages」"
echo "   3. 选择分支：master，目录：/"
echo "   4. 点击「启动」按钮"
echo ""
echo "🌐 网站访问地址："
echo "   https://${GITEE_USER}.gitee.io/${REPO_NAME}/"
echo ""
