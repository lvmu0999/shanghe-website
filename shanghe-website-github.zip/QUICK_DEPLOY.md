# 🚀 快速部署到 Gitee Pages

## 📋 部署前准备

### 1. SSH 公钥（已生成）

你的 SSH 公钥：
```
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDJuWLoiijPV0+WBUaNxriykf0g2eDZ9/Ns7c4X7d2FY admin@shanghe-agri.com
```

**操作步骤**：
1. 复制上面的公钥
2. 访问 https://gitee.com/profile/sshkeys
3. 点击「添加公钥」
4. 粘贴公钥，标题填"服务器"，确定

---

## 🎯 两种部署方式

### 方式一：使用部署脚本（推荐）

```bash
cd /home/admin/openclaw/workspace/shanghe-website

# 运行部署脚本（替换为你的 Gitee 用户名）
./deploy-to-gitee.sh 你的用户名
```

脚本会自动：
- ✅ 添加远程仓库
- ✅ 推送代码到 Gitee

### 方式二：手动命令

```bash
cd /home/admin/openclaw/workspace/shanghe-website

# 1. 添加远程仓库（替换为你的 Gitee 用户名）
git remote add origin git@gitee.com:你的用户名/shanghe-agri-website.git

# 2. 推送代码
git push -u origin master
```

---

## 🌐 启用 Pages 服务

代码推送成功后：

1. 访问你的仓库页面：
   ```
   https://gitee.com/你的用户名/shanghe-agri-website
   ```

2. 点击顶部菜单的「**管理**」

3. 左侧找到「**Gitee Pages**」

4. 配置并启动：
   - 来源分支：`master`
   - 站点目录：`/`
   - 强制 HTTPS：✅ 勾选
   - 点击「**启动**」

5. 等待 1-2 分钟，获得访问地址：
   ```
   https://你的用户名.gitee.io/shanghe-agri-website/
   ```

---

## ✅ 完成！

网站已上线！可以访问了。

---

## 🔄 后续更新

修改网站后，只需：

```bash
cd /home/admin/openclaw/workspace/shanghe-website

git add .
git commit -m "更新说明"
git push
```

自动重新部署，1-2 分钟生效。

---

## 📞 需要帮助？

查看完整文档：`DEPLOY_GITEE.md`
