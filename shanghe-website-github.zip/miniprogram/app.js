// app.js
App({
  onLaunch: function () {
    // 小程序启动时执行
    console.log('上禾智慧农业小程序启动');
    
    // 初始化语言
    const savedLang = wx.getStorageSync('shanghe-lang') || 'zh';
    this.globalData.currentLang = savedLang;
  },
  
  globalData: {
    currentLang: 'zh',
    supportedLanguages: ['zh', 'en', 'ru', 'kk'],
    userInfo: null
  }
})
