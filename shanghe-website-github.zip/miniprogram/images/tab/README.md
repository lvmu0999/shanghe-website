# TabBar 图标目录

## 🎨 获取图标的三种方式

### 方式一：使用 HTML 生成器（推荐）⭐

1. 在浏览器中打开 `create-icons.html`
2. 点击 8 个图标逐个下载
3. 将下载的 PNG 文件放入此目录

**文件**: `create-icons.html`

---

### 方式二：从 IconFont 下载

1. 访问 https://www.iconfont.cn/
2. 搜索关键词：home, industry, news, contact
3. 下载 PNG 格式（48x48px 或 96x96px）
4. 重命名并放入此目录

**推荐图标库**:
- 首页：搜索"首页"、"房子"、"home"
- 产业：搜索"农业"、"叶子"、"industry"
- 新闻：搜索"新闻"、"文档"、"news"
- 联系：搜索"电话"、"联系"、"contact"

---

### 方式三：使用设计工具

使用 Figma、Sketch、Photoshop 等工具设计图标，导出为 PNG 格式。

---

## 📁 所需图标清单

| 文件名 | 尺寸 | 颜色 | 说明 |
|--------|------|------|------|
| home.png | 48x48px | #999999 | 首页图标（未选中） |
| home-active.png | 48x48px | #2E7D32 | 首页图标（选中） |
| industry.png | 48x48px | #999999 | 产业图标（未选中） |
| industry-active.png | 48x48px | #4CAF50 | 产业图标（选中） |
| news.png | 48x48px | #999999 | 新闻图标（未选中） |
| news-active.png | 48x48px | #8BC34A | 新闻图标（选中） |
| contact.png | 48x48px | #999999 | 联系图标（未选中） |
| contact-active.png | 48x48px | #CDDC39 | 联系图标（选中） |

---

## ⚠️ 临时方案

如果暂时没有图标，可以修改 `app.json` 暂时不显示图标：

```json
{
  "tabBar": {
    "color": "#999999",
    "selectedColor": "#2E7D32",
    "list": [
      {
        "pagePath": "pages/index/index",
        "text": "首页"
        // 暂时注释掉 iconPath 和 selectedIconPath
      }
    ]
  }
}
```

---

**更新时间**: 2026 年 3 月 23 日
