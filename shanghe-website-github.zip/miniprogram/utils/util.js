// utils/util.js

/**
 * 格式化日期
 * @param {Date} date 日期对象
 * @returns {string} 格式化后的日期字符串
 */
const formatTime = (date) => {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hour = date.getHours();
  const minute = date.getMinutes();
  const second = date.getSeconds();

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`;
};

/**
 * 格式化数字（补零）
 * @param {number} n 数字
 * @returns {string} 格式化后的字符串
 */
const formatNumber = (n) => {
  const s = n.toString();
  return s[1] ? s : `0${s}`;
};

/**
 * 显示加载提示
 * @param {string} title 提示文字
 */
const showLoading = (title = '加载中...') => {
  wx.showLoading({
    title: title,
    mask: true
  });
};

/**
 * 隐藏加载提示
 */
const hideLoading = () => {
  wx.hideLoading();
};

/**
 * 显示提示
 * @param {string} title 提示文字
 * @param {string} icon 图标类型
 */
const showToast = (title, icon = 'none') => {
  wx.showToast({
    title: title,
    icon: icon,
    duration: 2000
  });
};

/**
 * 发起网络请求
 * @param {string} url 请求地址
 * @param {object} data 请求数据
 * @param {string} method 请求方法
 * @returns {Promise}
 */
const request = (url, data = {}, method = 'GET') => {
  return new Promise((resolve, reject) => {
    wx.request({
      url: url,
      data: data,
      method: method,
      header: {
        'Content-Type': 'application/json'
      },
      success: (res) => {
        resolve(res.data);
      },
      fail: (err) => {
        reject(err);
      }
    });
  });
};

/**
 * 保存到本地存储
 * @param {string} key 键名
 * @param {any} value 值
 */
const setStorage = (key, value) => {
  wx.setStorageSync(key, value);
};

/**
 * 从本地存储读取
 * @param {string} key 键名
 * @returns {any} 值
 */
const getStorage = (key) => {
  return wx.getStorageSync(key);
};

/**
 * 清除本地存储
 * @param {string} key 键名
 */
const removeStorage = (key) => {
  wx.removeStorageSync(key);
};

module.exports = {
  formatTime,
  formatNumber,
  showLoading,
  hideLoading,
  showToast,
  request,
  setStorage,
  getStorage,
  removeStorage
};
