#!/bin/bash
# TabBar 图标生成脚本
# 使用 ImageMagick 生成简单的 PNG 图标

# 检查是否安装 ImageMagick
if ! command -v convert &> /dev/null; then
    echo "❌ 未找到 ImageMagick，请先安装："
    echo "   Ubuntu/Debian: sudo apt-get install imagemagick"
    echo "   macOS: brew install imagemagick"
    echo "   Windows: 下载安装 https://imagemagick.org/"
    exit 1
fi

# 创建图标目录
mkdir -p images/tab

# 定义图标颜色
COLOR_HOME="#2E7D32"
COLOR_INDUSTRY="#4CAF50"
COLOR_NEWS="#8BC34A"
COLOR_CONTACT="#CDDC39"

echo "🎨 开始生成 TabBar 图标..."

# 生成首页图标（房子）
convert -size 96x96 xc:transparent \
    -fill "$COLOR_HOME" \
    -draw "polygon 48,10 80,40 80,85 65,85 65,55 31,55 31,85 16,85 16,40" \
    images/tab/home-active.png

convert -size 96x96 xc:transparent \
    -stroke "$COLOR_HOME" -strokewidth 4 -fill none \
    -draw "polygon 48,10 80,40 80,85 65,85 65,55 31,55 31,85 16,85 16,40" \
    images/tab/home.png

# 生成产业图标（麦穗）
convert -size 96x96 xc:transparent \
    -fill "$COLOR_INDUSTRY" \
    -draw "circle 48,48 48,20" \
    -draw "circle 48,48 30,30" \
    -draw "circle 48,48 66,30" \
    -draw "circle 48,48 20,48" \
    -draw "circle 48,48 76,48" \
    -draw "circle 48,48 30,66" \
    -draw "circle 48,48 66,66" \
    -draw "rectangle 44,48 52,85" \
    images/tab/industry-active.png

convert -size 96x96 xc:transparent \
    -stroke "$COLOR_INDUSTRY" -strokewidth 4 -fill none \
    -draw "circle 48,48 48,20" \
    -draw "circle 48,48 30,30" \
    -draw "circle 48,48 66,30" \
    -draw "circle 48,48 20,48" \
    -draw "circle 48,48 76,48" \
    -draw "circle 48,48 30,66" \
    -draw "circle 48,48 66,66" \
    -draw "rectangle 44,48 52,85" \
    images/tab/industry.png

# 生成新闻图标（报纸）
convert -size 96x96 xc:transparent \
    -fill "$COLOR_NEWS" \
    -draw "roundrectangle 20,15 76,80 5,5" \
    -fill white \
    -draw "rectangle 28,25 68,35" \
    -draw "rectangle 28,40 68,45" \
    -draw "rectangle 28,50 68,55" \
    -draw "rectangle 28,60 68,65" \
    images/tab/news-active.png

convert -size 96x96 xc:transparent \
    -stroke "$COLOR_NEWS" -strokewidth 4 -fill none \
    -draw "roundrectangle 20,15 76,80 5,5" \
    -stroke white -strokewidth 2 \
    -draw "line 28,25 68,25" \
    -draw "line 28,35 68,35" \
    -draw "line 28,45 68,45" \
    -draw "line 28,55 68,55" \
    images/tab/news.png

# 生成联系图标（电话）
convert -size 96x96 xc:transparent \
    -fill "$COLOR_CONTACT" \
    -draw "path 'M 30,25 C 30,20 35,15 40,15 L 45,15 C 50,15 55,20 55,25 L 55,35 C 55,40 50,45 45,45 L 40,45 C 35,45 30,40 30,35 Z'" \
    -draw "line 35,20 50,30" \
    -draw "line 35,35 50,25" \
    images/tab/contact-active.png

convert -size 96x96 xc:transparent \
    -stroke "$COLOR_CONTACT" -strokewidth 4 -fill none \
    -draw "path 'M 30,25 C 30,20 35,15 40,15 L 45,15 C 50,15 55,20 55,25 L 55,35 C 55,40 50,45 45,45 L 40,45 C 35,45 30,40 30,35 Z'" \
    images/tab/contact.png

echo "✅ TabBar 图标生成完成！"
echo "📁 图标位置：images/tab/"
ls -la images/tab/
