// pages/about/about.js
const app = getApp();
const i18n = require('../../data/i18n.js');

Page({
  data: {
    i18n: {}
  },

  onLoad: function () {
    this.updateLanguage();
  },

  updateLanguage: function() {
    const lang = app.globalData.currentLang;
    this.setData({
      i18n: i18n[lang] || i18n['zh']
    });
  }
})
