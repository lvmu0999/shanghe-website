// pages/news/news.js
const app = getApp();
const i18n = require('../../data/i18n.js');

Page({
  data: {
    i18n: {},
    currentCategory: 'all',
    hasMore: true,
    newsList: [
      {
        id: 1,
        title: '上禾农业与多家商超达成战略合作',
        summary: '公司近日与多家大型商超签订战略合作协议，进一步扩大产品销售渠道...',
        date: '2026-03-20',
        category: 'company',
        categoryText: '公司新闻'
      },
      {
        id: 2,
        title: '智慧农业系统正式上线运行',
        summary: '公司自主研发的智慧农业管理系统正式投入使用，实现农业生产全流程数字化管理...',
        date: '2026-03-15',
        category: 'company',
        categoryText: '公司新闻'
      },
      {
        id: 3,
        title: '有机蔬菜基地获得国际认证',
        summary: '公司旗下有机蔬菜基地顺利通过国际有机农业认证，产品品质达到国际标准...',
        date: '2026-03-10',
        category: 'company',
        categoryText: '公司新闻'
      },
      {
        id: 4,
        title: '2026 年中央一号文件发布，聚焦乡村振兴',
        summary: '国家发布 2026 年中央一号文件，继续聚焦乡村振兴战略...',
        date: '2026-02-28',
        category: 'industry',
        categoryText: '行业资讯'
      },
      {
        id: 5,
        title: '现代农业发展趋势报告',
        summary: '行业报告显示，智慧农业、有机农业将成为未来农业发展的重要方向...',
        date: '2026-02-20',
        category: 'industry',
        categoryText: '行业资讯'
      }
    ]
  },

  onLoad: function () {
    this.updateLanguage();
  },

  updateLanguage: function() {
    const lang = app.globalData.currentLang;
    this.setData({
      i18n: i18n[lang] || i18n['zh']
    });
  },

  changeCategory: function(e) {
    const category = e.currentTarget.dataset.category;
    this.setData({
      currentCategory: category
    });
    this.loadNews();
  },

  loadNews: function() {
    // 实际项目中应从 API 加载
    wx.showToast({
      title: '加载中...',
      icon: 'none'
    });
  },

  goToDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/news-detail/news-detail?id=${id}`
    });
  }
})
