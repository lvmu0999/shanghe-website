// pages/index/index.js
const app = getApp();
const i18n = require('../../data/i18n.js');

Page({
  data: {
    i18n: {},
    banners: [
      { id: 1, image: '/images/banner1.jpg' },
      { id: 2, image: '/images/banner2.jpg' },
      { id: 3, image: '/images/banner3.jpg' }
    ],
    stats: [
      { key: 'capital', value: '5000', label: '万元' },
      { key: 'scale', value: '100 万', label: '头/只' },
      { key: 'area', value: '5 万', label: '亩' },
      { key: 'staff', value: '100+', label: '人' }
    ]
  },

  onLoad: function () {
    this.updateLanguage();
  },

  updateLanguage: function() {
    const lang = app.globalData.currentLang;
    this.setData({
      i18n: i18n[lang] || i18n['zh']
    });
  },

  goToAbout: function() {
    wx.navigateTo({
      url: '/pages/about/about'
    });
  },

  goToPage: function(e) {
    const page = e.currentTarget.dataset.page;
    wx.navigateTo({
      url: page
    });
  }
})
