// pages/lang/lang.js
const app = getApp();
const i18n = require('../../data/i18n.js');

Page({
  data: {
    i18n: {},
    currentLang: 'zh',
    languages: [
      { code: 'zh', name: '中文', native: 'Chinese', flag: '🇨🇳' },
      { code: 'en', name: '英语', native: 'English', flag: '🇬🇧' },
      { code: 'ru', name: '俄语', native: 'Русский', flag: '🇷🇺' },
      { code: 'kk', name: '哈萨克语', native: 'Қазақша', flag: '🇰🇿' }
    ]
  },

  onLoad: function () {
    const savedLang = app.globalData.currentLang || 'zh';
    this.setData({
      currentLang: savedLang
    });
    this.updateLanguage();
  },

  updateLanguage: function() {
    const lang = this.data.currentLang;
    this.setData({
      i18n: i18n[lang] || i18n['zh']
    });
  },

  switchLang: function(e) {
    const lang = e.currentTarget.dataset.lang;
    
    if (lang === this.data.currentLang) {
      return;
    }

    this.setData({
      currentLang: lang
    });

    // 保存到全局数据
    app.globalData.currentLang = lang;
    
    // 保存到本地存储
    wx.setStorageSync('shanghe-lang', lang);

    // 更新页面语言
    this.updateLanguage();

    // 提示用户
    const langNames = {
      'zh': '中文',
      'en': 'English',
      'ru': 'Русский',
      'kk': 'Қазақша'
    };

    wx.showToast({
      title: `已切换到 ${langNames[lang]}`,
      icon: 'success',
      duration: 2000
    });

    // 刷新上一页（如果有）
    const pages = getCurrentPages();
    if (pages.length > 1) {
      const prevPage = pages[pages.length - 2];
      if (prevPage.updateLanguage) {
        prevPage.updateLanguage();
      }
    }
  }
})
