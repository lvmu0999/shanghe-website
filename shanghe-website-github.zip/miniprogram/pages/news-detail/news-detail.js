// pages/news-detail/news-detail.js
const app = getApp();
const i18n = require('../../data/i18n.js');

Page({
  data: {
    i18n: {},
    newsId: null,
    newsItem: {
      id: 1,
      title: '上禾农业与多家商超达成战略合作',
      date: '2026-03-20',
      categoryText: '公司新闻',
      content: '公司近日与多家大型商超签订战略合作协议，进一步扩大产品销售渠道。此次合作涵盖了北京、上海、广州、深圳等一线城市的主要连锁超市，以及新疆本地的多家商超。\n\n根据协议，上禾农业将为这些商超提供优质的有机蔬菜、生态养殖产品等农产品。所有产品均经过严格的质量检测，确保食品安全和品质。\n\n公司负责人表示，此次战略合作标志着上禾农业在市场化道路上迈出了重要一步，将为更多消费者提供安全、健康、优质的农产品。'
    },
    relatedNews: [
      { id: 2, title: '智慧农业系统正式上线运行', date: '2026-03-15' },
      { id: 3, title: '有机蔬菜基地获得国际认证', date: '2026-03-10' },
      { id: 4, title: '2026 年中央一号文件发布', date: '2026-02-28' }
    ]
  },

  onLoad: function (options) {
    this.setData({
      newsId: options.id || 1
    });
    this.updateLanguage();
    this.loadNewsDetail();
  },

  updateLanguage: function() {
    const lang = app.globalData.currentLang;
    this.setData({
      i18n: i18n[lang] || i18n['zh']
    });
  },

  loadNewsDetail: function() {
    // 实际项目中应从 API 加载
    wx.showToast({
      title: '加载成功',
      icon: 'success'
    });
  },

  shareNews: function() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
    wx.showToast({
      title: '点击右上角分享',
      icon: 'none'
    });
  },

  goToNews: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/news-detail/news-detail?id=${id}`
    });
  },

  onShareAppMessage: function() {
    return {
      title: this.data.newsItem.title,
      path: `/pages/news-detail/news-detail?id=${this.data.newsId}`
    };
  }
})
