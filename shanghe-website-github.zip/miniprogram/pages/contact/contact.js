// pages/contact/contact.js
const app = getApp();
const i18n = require('../../data/i18n.js');

Page({
  data: {
    i18n: {}
  },

  onLoad: function () {
    this.updateLanguage();
  },

  updateLanguage: function() {
    const lang = app.globalData.currentLang;
    this.setData({
      i18n: i18n[lang] || i18n['zh']
    });
  },

  makePhoneCall: function() {
    wx.makePhoneCall({
      phoneNumber: '086-0999-5036228',
      fail: function() {
        wx.showToast({
          title: '拨号失败',
          icon: 'none'
        });
      }
    });
  },

  sendEmail: function() {
    wx.setClipboardData({
      data: '1131680431@qq.com',
      success: function() {
        wx.showToast({
          title: '邮箱已复制',
          icon: 'success'
        });
      }
    });
  },

  openLocation: function() {
    wx.openLocation({
      latitude: 43.4269,
      longitude: 83.2661,
      name: '上禾智慧农业',
      address: '新疆伊犁新源县 72 团农业产业园',
      scale: 15
    });
  },

  submitForm: function() {
    wx.showToast({
      title: '提交成功',
      icon: 'success'
    });
  }
})
