// pages/industry/industry.js
const app = getApp();
const i18n = require('../../data/i18n.js');

Page({
  data: {
    i18n: {},
    industries: [
      {
        id: 1,
        icon: '🌱',
        title: '有机种植',
        description: '采用国际有机农业标准，生产绿色健康的蔬菜、水果、粮食等农产品',
        features: ['50000+ 亩基地', '有机认证', '全程追溯']
      },
      {
        id: 2,
        icon: '🐄',
        title: '生态养殖',
        description: '科学养殖管理，提供优质的畜禽产品和水产品',
        features: ['100 万头规模', '生态循环', '安全健康']
      },
      {
        id: 3,
        icon: '🏭',
        title: '农产品加工',
        description: '现代化加工生产线，提升农产品附加值',
        features: ['先进设备', '严格品控', '深加工']
      },
      {
        id: 4,
        icon: '📱',
        title: '智慧农业',
        description: '物联网、大数据、人工智能技术赋能农业生产',
        features: ['智能监控', '数据分析', '精准管理']
      },
      {
        id: 5,
        icon: '🚚',
        title: '食品流通',
        description: '从田间到餐桌的完整供应链，保障产品新鲜送达',
        features: ['冷链物流', '全国网络', '快速配送']
      }
    ]
  },

  onLoad: function () {
    this.updateLanguage();
  },

  updateLanguage: function() {
    const lang = app.globalData.currentLang;
    this.setData({
      i18n: i18n[lang] || i18n['zh']
    });
  },

  goToDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.showToast({
      title: '敬请期待',
      icon: 'none'
    });
  }
})
