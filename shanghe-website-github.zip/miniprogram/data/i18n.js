// data/i18n.js - 多语言数据
module.exports = {
  zh: {
    'nav-home': '首页',
    'nav-about': '关于上禾',
    'nav-industry': '产业布局',
    'nav-news': '新闻动态',
    'footer-contact': '联系我们',
    'about-title': '关于上禾',
    'about-subtitle': 'ABOUT SHANGHE',
    'about-lead': '新疆上禾智慧农业发展有限责任公司是以科技为主导的现代化农业企业，致力于生态农业全产业链发展。',
    'about-btn-more': '了解更多',
    'stats-capital': '注册资金',
    'stats-scale': '养殖规模',
    'stats-area': '种植基地',
    'stats-staff': '员工数量'
  },
  en: {
    'nav-home': 'Home',
    'nav-about': 'About Us',
    'nav-industry': 'Industries',
    'nav-news': 'News',
    'footer-contact': 'Contact',
    'about-title': 'About Shanghe',
    'about-subtitle': 'ABOUT SHANGHE',
    'about-lead': 'Xinjiang Shanghe Smart Agriculture is a technology-led modern agricultural enterprise.',
    'about-btn-more': 'Learn More',
    'stats-capital': 'Capital',
    'stats-scale': 'Breeding Scale',
    'stats-area': 'Planting Base',
    'stats-staff': 'Employees'
  },
  ru: {
    'nav-home': 'Главная',
    'nav-about': 'О компании',
    'nav-industry': 'Отрасли',
    'nav-news': 'Новости',
    'footer-contact': 'Контакты',
    'about-title': 'О Шанхэ',
    'about-subtitle': 'О КОМПАНИИ',
    'about-lead': 'Синьцзян Шанхэ - современное сельскохозяйственное предприятие.',
    'about-btn-more': 'Узнать больше',
    'stats-capital': 'Капитал',
    'stats-scale': 'Масштаб',
    'stats-area': 'База',
    'stats-staff': 'Сотрудники'
  },
  kk: {
    'nav-home': 'Басты бет',
    'nav-about': 'Біз туралы',
    'nav-industry': 'Салалар',
    'nav-news': 'Жаңалықтар',
    'footer-contact': 'Байланыс',
    'about-title': 'Шанхэ туралы',
    'about-subtitle': 'БІЗ ТУРАЛЫ',
    'about-lead': 'Синьцзян Шанхэ - заманауи ауыл шаруашылығы кәсіпорны.',
    'about-btn-more': 'Толығырақ',
    'stats-capital': 'Капитал',
    'stats-scale': 'Масштаб',
    'stats-area': 'База',
    'stats-staff': 'Қызметкерлер'
  }
};
