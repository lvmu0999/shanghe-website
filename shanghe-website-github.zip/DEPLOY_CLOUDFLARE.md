# Cloudflare Pages 自动部署指南

## ✅ 部署状态

**状态**: 已部署  
**生产域名**: https://master.shanghe-agri-website.pages.dev  
**预览域名**: https://6d7f6333.shanghe-agri-website.pages.dev  
**部署时间**: 2026-03-23 12:41

---

## 🔑 获取 Cloudflare API Token

1. 访问：https://dash.cloudflare.com/profile/api-tokens
2. 点击 **「Create Token」**
3. 选择 **「Edit Cloudflare Workers」** 模板（或自定义权限）
4. 权限要求：
   - `Account Cloudflare Pages` = `Edit`
   - `Account Cloudflare R2` = `Read` (可选)
5. 点击 **「Continue to summary」** → **「Create Token」**
6. **复制 Token**（只显示一次！）

## 🚀 部署命令

```bash
# 设置 API Token（替换 YOUR_TOKEN）
export CLOUDFLARE_API_TOKEN="你的 Token"

# 进入项目目录
cd /home/admin/openclaw/workspace/shanghe-website

# 部署到 Cloudflare Pages
wrangler pages deploy . --project-name=shanghe-agri-website --branch=master
```

## 📝 或者使用项目级配置

创建 `.wrangler/config.json`:
```json
{
  "pages": {
    "project_name": "shanghe-agri-website",
    "branch": "master"
  }
}
```

然后运行：
```bash
wrangler pages deploy .
```

## 🌐 访问地址

部署成功后，你将获得：
- **生产域名**: `https://shanghe-agri-website.pages.dev`
- **预览域名**: 每次 commit 都会生成预览链接

## 🔗 绑定自定义域名（可选）

在 Cloudflare Dashboard 中：
1. Pages → shanghe-agri-website → Custom domains
2. 点击 **「Add custom domain」**
3. 输入你的域名（如 `www.shanghe-agri.com`）
4. 自动配置 DNS 和 SSL
