// 新闻动态数据 - 多语言版本
const newsData = {
    zh: [
        {
            id: 1,
            title: '上禾农业与多家商超达成战略合作',
            summary: '公司近日与多家大型商超签订战略合作协议，进一步扩大产品销售渠道，为消费者提供更便捷的购买体验。',
            content: '详细内容...',
            date: '2026-03-20',
            category: 'company',
            image: 'images/news/news-1.jpg',
            author: '上禾集团'
        },
        {
            id: 2,
            title: '智慧农业系统正式上线运行',
            summary: '公司自主研发的智慧农业管理系统正式投入使用，实现农业生产全流程数字化管理，大幅提升生产效率。',
            content: '详细内容...',
            date: '2026-03-15',
            category: 'company',
            image: 'images/news/news-2.jpg',
            author: '技术部'
        },
        {
            id: 3,
            title: '有机蔬菜基地获得国际认证',
            summary: '公司旗下有机蔬菜基地顺利通过国际有机农业认证，产品品质达到国际标准，为出口奠定基础。',
            content: '详细内容...',
            date: '2026-03-10',
            category: 'company',
            image: 'images/news/news-3.jpg',
            author: '品质部'
        }
    ],
    en: [
        {
            id: 1,
            title: 'Shanghe Agriculture Strategic Partnership with Supermarkets',
            summary: 'The company recently signed strategic cooperation agreements with multiple large supermarkets to further expand product sales channels.',
            content: 'Details...',
            date: '2026-03-20',
            category: 'company',
            image: 'images/news/news-1.jpg',
            author: 'Shanghe Group'
        },
        {
            id: 2,
            title: 'Smart Agriculture System Officially Launched',
            summary: 'The smart agriculture management system independently developed by the company has been put into use, achieving digital management of the entire agricultural production process.',
            content: 'Details...',
            date: '2026-03-15',
            category: 'company',
            image: 'images/news/news-2.jpg',
            author: 'Technology Department'
        },
        {
            id: 3,
            title: 'Organic Vegetable Base Receives International Certification',
            summary: 'The organic vegetable base under the company has successfully passed international organic agriculture certification.',
            content: 'Details...',
            date: '2026-03-10',
            category: 'company',
            image: 'images/news/news-3.jpg',
            author: 'Quality Department'
        }
    ],
    ru: [
        {
            id: 1,
            title: 'Стратегическое партнерство с супермаркетами',
            summary: 'Компания подписала соглашения о стратегическом сотрудничестве с несколькими крупными супермаркетами.',
            content: 'Подробности...',
            date: '2026-03-20',
            category: 'company',
            image: 'images/news/news-1.jpg',
            author: 'Шанхэ Групп'
        }
    ],
    kk: [
        {
            id: 1,
            title: 'Супермаркеттермен стратегиялық серіктестік',
            summary: 'Компания бірнеше ірі супермаркеттермен стратегиялық ынтымақтастық туралы келісімшарттар жасасты.',
            content: 'Толығырақ...',
            date: '2026-03-20',
            category: 'company',
            image: 'images/news/news-1.jpg',
            author: 'Шанхэ Тобы'
        }
    ]
};

// 获取当前语言
function getCurrentLang() {
    return localStorage.getItem('shanghe-lang') || 'zh';
}

// 获取新闻列表
function getNewsList(category = null, limit = 10) {
    const lang = getCurrentLang();
    let filtered = newsData[lang] || newsData['zh'];
    if (category) {
        filtered = filtered.filter(news => news.category === category);
    }
    return filtered.slice(0, limit);
}

// 获取新闻详情
function getNewsById(id) {
    const lang = getCurrentLang();
    const newsList = newsData[lang] || newsData['zh'];
    return newsList.find(news => news.id === parseInt(id));
}

// 渲染新闻列表
function renderNewsList(containerId, category = null, limit = 6) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    const newsList = getNewsList(category, limit);
    container.innerHTML = newsList.map(news => `
        <article class="news-card">
            <div class="news-image">
                <img src="${news.image}" alt="${news.title}" onerror="this.parentElement.innerHTML='<div class=\\'image-placeholder\\'><svg viewBox=\\'0 0 300 200\\' width=\\'100%\\' height=\\'100%\\'><rect fill=\\'#C8E6C9\\' width=\\'300\\' height=\\'200\\'/><text x=\\'150\\' y=\\'95\\' text-anchor=\\'middle\\' fill=\\'#2E7D32\\' font-size=\\'14\\'>新闻图片</text></svg></div>'">
            </div>
            <div class="news-content">
                <span class="news-date">${news.date}</span>
                <h3>${news.title}</h3>
                <p>${news.summary}</p>
                <a href="news-detail.html?id=${news.id}" class="read-more">阅读更多 →</a>
            </div>
        </article>
    `).join('');
}

// 页面加载时自动渲染
document.addEventListener('DOMContentLoaded', function() {
    // 如果在新闻列表页面，自动渲染
    if (window.location.pathname.includes('news.html')) {
        renderNewsList('news-list-container');
    }
    
    // 如果在新闻详情页面，自动加载详情
    if (window.location.pathname.includes('news-detail.html')) {
        const urlParams = new URLSearchParams(window.location.search);
        const newsId = urlParams.get('id');
        if (newsId) {
            loadNewsDetail(newsId);
        }
    }
});

// 加载新闻详情
function loadNewsDetail(newsId) {
    const news = getNewsById(newsId);
    if (!news) {
        document.getElementById('news-detail-container').innerHTML = '<p>新闻不存在</p>';
        return;
    }
    
    document.getElementById('news-detail-container').innerHTML = `
        <article class="news-detail">
            <h1>${news.title}</h1>
            <div class="news-meta">
                <span>发布时间：${news.date}</span>
                <span>来源：${news.author}</span>
            </div>
            <div class="news-content">
                <p>${news.content}</p>
            </div>
        </article>
    `;
}
