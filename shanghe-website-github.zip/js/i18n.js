// 多语言支持
const i18n = {
    zh: {
        // 导航
        'nav-home': '首页',
        'nav-about': '关于上禾',
        'nav-industry': '产业布局',
        'nav-technology': '科技研发',
        'nav-news': '新闻动态',
        'nav-investor': '投资者关系',
        'nav-careers': '人才中心',
        
        // 导航下拉菜单 - 关于上禾
        'nav-about-1': '了解上禾',
        'nav-about-2': '企业文化',
        'nav-about-3': '发展历程',
        'nav-about-4': '荣誉资质',
        'nav-about-5': '联系我们',
        
        // 导航下拉菜单 - 产业布局
        'nav-industry-1': '有机种植',
        'nav-industry-2': '生态养殖',
        'nav-industry-3': '农产品加工',
        'nav-industry-4': '智慧农业',
        'nav-industry-5': '食品流通',
        
        // 导航下拉菜单 - 科技研发
        'nav-tech-1': '研发体系',
        'nav-tech-2': '科研团队',
        'nav-tech-3': '科研成果',
        'nav-tech-4': '技术专利',
        
        // 导航下拉菜单 - 新闻动态
        'nav-news-1': '公司新闻',
        'nav-news-2': '行业资讯',
        'nav-news-3': '媒体报道',
        'nav-news-4': '公示公告',
        
        // Hero 轮播
        'hero-title-1': '发展生态农业',
        'hero-subtitle-1': '建设美丽乡村',
        'hero-title-2': '智慧农业引领未来',
        'hero-subtitle-2': '科技驱动农业现代化',
        'hero-title-3': '从田间到餐桌',
        'hero-subtitle-3': '全产业链品质保障',
        
        // 关于板块
        'about-title': '关于上禾',
        'about-subtitle': 'ABOUT SHANGHE',
        'about-lead': '新疆上禾智慧农业发展有限责任公司是以科技为主导的现代化农业企业，致力于生态农业全产业链发展。',
        'about-btn-more': '了解更多',
        'about-btn-video': '观看企业视频',
        
        // 关于页面
        'about-page-title': '关于上禾',
        'about-page-subtitle': '企业简介',
        'about-page-lead': '新疆上禾智慧农业发展有限责任公司是以科技为主导的现代化农业企业',
        'about-culture-title': '企业文化',
        'about-history-title': '发展历程',
        'about-honors-title': '荣誉资质',
        
        // 产业布局
        'industry-title': '产业布局',
        'industry-subtitle': 'INDUSTRIAL LAYOUT',
        'industry-planting': '有机种植',
        'industry-breeding': '生态养殖',
        'industry-processing': '农产品加工',
        'industry-smart': '智慧农业',
        'industry-food': '食品流通',
        
        // 数据统计
        'stats-title': '数据统计',
        'stats-capital': '注册资金（万元）',
        'stats-scale': '养殖规模（头/只）',
        'stats-area': '种植基地（亩）',
        'stats-staff': '员工数量（人）',
        'stats-farmers': '服务农户（户）',
        'stats-products': '产品品类',
        
        // 荣誉资质
        'honors-title': '荣誉资质',
        'honors-subtitle': 'HONORS & AWARDS',
        'honor-1': '农业产业化重点龙头企业',
        'honor-2': '绿色食品认证',
        'honor-3': '有机产品认证',
        'honor-4': '科技创新企业',
        
        // 新闻动态
        'news-title': '新闻动态',
        'news-subtitle': 'NEWS & EVENTS',
        'news-more': '查看更多新闻',
        'news-filter-all': '全部新闻',
        'news-filter-company': '公司新闻',
        'news-filter-industry': '行业资讯',
        'news-filter-media': '媒体报道',
        'news-filter-notice': '公示公告',
        
        // 页脚
        'footer-about': '关于上禾',
        'footer-industry': '产业布局',
        'footer-tech': '科技研发',
        'footer-news': '新闻动态',
        'footer-contact': '联系方式',
        'footer-links': '网站地图 | 网站声明 | 隐私政策',
        'footer-copyright': '© 2026 新疆上禾智慧农业发展有限责任公司 版权所有',
        'footer-icp': 'ICP 备案号：新 ICP 备 XXXXXXXX 号',
        
        // 页脚 - 关于上禾
        'footer-about-1': '了解上禾',
        'footer-about-2': '企业文化',
        'footer-about-3': '发展历程',
        'footer-about-4': '荣誉资质',
        'footer-about-5': '联系我们',
        
        // 页脚 - 产业布局
        'footer-industry-1': '有机种植',
        'footer-industry-2': '生态养殖',
        'footer-industry-3': '农产品加工',
        'footer-industry-4': '智慧农业',
        'footer-industry-5': '食品流通',
        
        // 页脚 - 科技研发
        'footer-tech-1': '研发体系',
        'footer-tech-2': '科研团队',
        'footer-tech-3': '科研成果',
        'footer-tech-4': '技术专利',
        
        // 页脚 - 新闻动态
        'footer-news-1': '公司新闻',
        'footer-news-2': '行业资讯',
        'footer-news-3': '媒体报道',
        'footer-news-4': '公示公告',
        
        // 页脚 - 联系方式
        'footer-phone': '电话',
        'footer-email': '邮箱',
        'footer-address': '地址',
        'footer-postcode': '邮编',
        'footer-hours': '营业时间',
        
        // 联系页面
        'contact-title': '联系我们',
        'contact-info-title': '联系方式',
        'contact-phone-title': '电话咨询',
        'contact-phone-desc': '周一至周五 9:00-20:00',
        'contact-email-title': '邮箱联系',
        'contact-email-desc': '工作日 24 小时内回复',
        'contact-address-title': '公司地址',
        'contact-address-desc': '邮编：835800',
        'contact-hours-title': '营业时间',
        'contact-hours-desc': '周六至周日：10:00 - 18:00',
        'contact-form-title': '在线留言',
        'contact-form-desc': '请填写以下表单，我们将尽快与您联系',
        'contact-form-name': '姓名',
        'contact-form-phone': '电话',
        'contact-form-email': '邮箱',
        'contact-form-company': '公司',
        'contact-form-subject': '主题',
        'contact-form-message': '留言内容',
        'contact-form-submit': '提交留言',
        'contact-form-tips': '温馨提示',
        'contact-form-tip-1': '工作日 24 小时内回复',
        'contact-form-tip-2': '周末及节假日 48 小时内回复',
        'contact-form-tip-3': '紧急事宜请直接拨打电话',
        'contact-map-title': '公司位置'
    },
    
    en: {
        // Navigation
        'nav-home': 'Home',
        'nav-about': 'About Us',
        'nav-industry': 'Industries',
        'nav-technology': 'R&D',
        'nav-news': 'News',
        'nav-investor': 'Investors',
        'nav-careers': 'Careers',
        
        // Nav Dropdown - About
        'nav-about-1': 'About Shanghe',
        'nav-about-2': 'Our Culture',
        'nav-about-3': 'History',
        'nav-about-4': 'Honors',
        'nav-about-5': 'Contact Us',
        
        // Nav Dropdown - Industries
        'nav-industry-1': 'Organic Planting',
        'nav-industry-2': 'Ecological Breeding',
        'nav-industry-3': 'Agricultural Processing',
        'nav-industry-4': 'Smart Agriculture',
        'nav-industry-5': 'Food Distribution',
        
        // Nav Dropdown - Technology
        'nav-tech-1': 'R&D System',
        'nav-tech-2': 'Research Team',
        'nav-tech-3': 'Achievements',
        'nav-tech-4': 'Patents',
        
        // Nav Dropdown - News
        'nav-news-1': 'Company News',
        'nav-news-2': 'Industry News',
        'nav-news-3': 'Media Reports',
        'nav-news-4': 'Announcements',
        
        // Hero
        'hero-title-1': 'Ecological Agriculture',
        'hero-subtitle-1': 'Building Beautiful Countryside',
        'hero-title-2': 'Smart Agriculture',
        'hero-subtitle-2': 'Technology-Driven Modernization',
        'hero-title-3': 'Farm to Table',
        'hero-subtitle-3': 'Full Chain Quality Assurance',
        
        // About
        'about-title': 'About Shanghe',
        'about-subtitle': 'ABOUT SHANGHE',
        'about-lead': 'Xinjiang Shanghe Smart Agriculture Development Co., Ltd. is a technology-led modern agricultural enterprise dedicated to the development of the entire ecological agriculture industry chain.',
        'about-btn-more': 'Learn More',
        'about-btn-video': 'Watch Video',
        
        // About Page
        'about-page-title': 'About Shanghe',
        'about-page-subtitle': 'Company Profile',
        'about-page-lead': 'Xinjiang Shanghe Smart Agriculture Development Co., Ltd. is a technology-led modern agricultural enterprise',
        'about-culture-title': 'Our Culture',
        'about-history-title': 'History',
        'about-honors-title': 'Honors',
        
        // Industries
        'industry-title': 'Industries',
        'industry-subtitle': 'INDUSTRIAL LAYOUT',
        'industry-planting': 'Organic Planting',
        'industry-breeding': 'Ecological Breeding',
        'industry-processing': 'Agricultural Processing',
        'industry-smart': 'Smart Agriculture',
        'industry-food': 'Food Distribution',
        
        // Statistics
        'stats-title': 'Statistics',
        'stats-capital': 'Registered Capital (10K Yuan)',
        'stats-scale': 'Breeding Scale',
        'stats-area': 'Planting Base (Mu)',
        'stats-staff': 'Employees',
        'stats-farmers': 'Service Farmers',
        'stats-products': 'Product Categories',
        
        // Honors
        'honors-title': 'Honors',
        'honors-subtitle': 'HONORS & AWARDS',
        'honor-1': 'Key Leading Enterprise in Agricultural Industrialization',
        'honor-2': 'Green Food Certification',
        'honor-3': 'Organic Product Certification',
        'honor-4': 'Technology Innovation Enterprise',
        
        // News
        'news-title': 'News',
        'news-subtitle': 'NEWS & EVENTS',
        'news-more': 'View More News',
        'news-filter-all': 'All News',
        'news-filter-company': 'Company News',
        'news-filter-industry': 'Industry News',
        'news-filter-media': 'Media Reports',
        'news-filter-notice': 'Announcements',
        
        // Footer
        'footer-about': 'About',
        'footer-industry': 'Industries',
        'footer-tech': 'R&D',
        'footer-news': 'News',
        'footer-contact': 'Contact',
        'footer-links': 'Sitemap | Terms | Privacy',
        'footer-copyright': '© 2026 Xinjiang Shanghe Smart Agriculture Development Co., Ltd. All Rights Reserved.',
        'footer-icp': 'ICP: Xin ICP No. XXXXXXXX',
        
        // Footer - About
        'footer-about-1': 'About Shanghe',
        'footer-about-2': 'Our Culture',
        'footer-about-3': 'History',
        'footer-about-4': 'Honors',
        'footer-about-5': 'Contact Us',
        
        // Footer - Industries
        'footer-industry-1': 'Organic Planting',
        'footer-industry-2': 'Ecological Breeding',
        'footer-industry-3': 'Agricultural Processing',
        'footer-industry-4': 'Smart Agriculture',
        'footer-industry-5': 'Food Distribution',
        
        // Footer - Technology
        'footer-tech-1': 'R&D System',
        'footer-tech-2': 'Research Team',
        'footer-tech-3': 'Achievements',
        'footer-tech-4': 'Patents',
        
        // Footer - News
        'footer-news-1': 'Company News',
        'footer-news-2': 'Industry News',
        'footer-news-3': 'Media Reports',
        'footer-news-4': 'Announcements',
        
        // Footer - Contact
        'footer-phone': 'Phone',
        'footer-email': 'Email',
        'footer-address': 'Address',
        'footer-postcode': 'Postcode',
        'footer-hours': 'Business Hours',
        
        // Contact Page
        'contact-title': 'Contact Us',
        'contact-info-title': 'Contact Information',
        'contact-phone-title': 'Phone',
        'contact-phone-desc': 'Mon-Fri 9:00-20:00',
        'contact-email-title': 'Email',
        'contact-email-desc': 'Reply within 24 hours on weekdays',
        'contact-address-title': 'Address',
        'contact-address-desc': 'Postcode: 835800',
        'contact-hours-title': 'Business Hours',
        'contact-hours-desc': 'Sat-Sun: 10:00 - 18:00',
        'contact-form-title': 'Leave a Message',
        'contact-form-desc': 'Please fill in the form below and we will contact you as soon as possible',
        'contact-form-name': 'Name',
        'contact-form-phone': 'Phone',
        'contact-form-email': 'Email',
        'contact-form-company': 'Company',
        'contact-form-subject': 'Subject',
        'contact-form-message': 'Message',
        'contact-form-submit': 'Submit',
        'contact-form-tips': 'Tips',
        'contact-form-tip-1': 'Reply within 24 hours on weekdays',
        'contact-form-tip-2': 'Reply within 48 hours on weekends',
        'contact-form-tip-3': 'For urgent matters, please call directly',
        'contact-map-title': 'Our Location'
    },
    
    ru: {
        // Навигация
        'nav-home': 'Главная',
        'nav-about': 'О компании',
        'nav-industry': 'Отрасли',
        'nav-technology': 'НИОКР',
        'nav-news': 'Новости',
        'nav-investor': 'Инвесторам',
        'nav-careers': 'Карьера',
        
        // О компании
        'about-title': 'О Шанхэ',
        'about-subtitle': 'О КОМПАНИИ',
        'about-lead': 'Синьцзян Шанхэ Смарт Агрикультура - современное сельскохозяйственное предприятие, занимающееся развитием экологического сельского хозяйства.',
        'about-btn-more': 'Узнать больше',
        'about-btn-video': 'Смотреть видео',
        
        // Отрасли
        'industry-title': 'Отрасли',
        'industry-subtitle': 'ПРОМЫШЛЕННАЯ СТРУКТУРА',
        'industry-planting': 'Органическое земледелие',
        'industry-breeding': 'Экологическое животноводство',
        'industry-processing': 'Переработка продукции',
        'industry-smart': 'Умное сельское хозяйство',
        'industry-food': 'Распространение продуктов',
        
        // Статистика
        'stats-title': 'Статистика',
        'stats-capital': 'Уставный капитал',
        'stats-scale': 'Масштаб разведения',
        'stats-area': 'База посадки',
        'stats-staff': 'Сотрудники',
        'stats-farmers': 'Обслуживаемые фермеры',
        'stats-products': 'Категории продуктов',
        
        // Новости
        'news-title': 'Новости',
        'news-subtitle': 'НОВОСТИ И СОБЫТИЯ',
        'news-more': 'Посмотреть больше',
        
        // Подвал
        'footer-contact': 'Контакты',
        'footer-copyright': '© 2026 Синьцзян Шанхэ Смарт Агрикультура. Все права защищены.',
        'footer-phone': 'Телефон',
        'footer-email': 'Email',
        'footer-address': 'Адрес'
    },
    
    kk: {
        // Навигация
        'nav-home': 'Басты бет',
        'nav-about': 'Біз туралы',
        'nav-industry': 'Салалар',
        'nav-technology': 'Зерттеу',
        'nav-news': 'Жаңалықтар',
        'nav-investor': 'Инвесторлар',
        'nav-careers': 'Мансап',
        
        // Біз туралы
        'about-title': 'Шанхэ туралы',
        'about-subtitle': 'БІЗ ТУРАЛЫ',
        'about-lead': 'Синьцзян Шанхэ Смарт Агрикультура - экологиялық ауыл шаруашылығын дамытуға арналған заманауи кәсіпорын.',
        'about-btn-more': 'Толығырақ',
        'about-btn-video': 'Видеоны көру',
        
        // Салалар
        'industry-title': 'Салалар',
        'industry-subtitle': 'ӨНДІРІСТІК ҚҰРЫЛЫМ',
        'industry-planting': 'Органикалық егіншілік',
        'industry-breeding': 'Экологиялық мал шаруашылығы',
        'industry-processing': 'Өнімді өңдеу',
        'industry-smart': 'Ақылды ауыл шаруашылығы',
        'industry-food': 'Тағам тарату',
        
        // Статистика
        'stats-title': 'Статистика',
        'stats-capital': 'Жарғылық капитал',
        'stats-scale': 'Мал шаруашылығы',
        'stats-area': 'Егіс алқабы',
        'stats-staff': 'Қызметкерлер',
        'stats-farmers': 'Қызмет көрсету фермерлер',
        'stats-products': 'Өнім санаттары',
        
        // Жаңалықтар
        'news-title': 'Жаңалықтар',
        'news-subtitle': 'ЖАҢАЛЫҚТАР МЕН ОҚИҒАЛАР',
        'news-more': 'Көбірек көру',
        
        // Подвал
        'footer-contact': 'Байланыс',
        'footer-copyright': '© 2026 Синьцзян Шанхэ Смарт Агрикультура. Барлық құқықтар қорғалған.',
        'footer-phone': 'Телефон',
        'footer-email': 'Email',
        'footer-address': 'Мекенжай'
    }
};

// 当前语言
let currentLang = 'zh';

// 支持的语言列表
const supportedLanguages = ['zh', 'en', 'ru', 'kk'];

// 语言名称映射
const languageNames = {
    'zh': '中文',
    'en': 'EN',
    'ru': 'RU',
    'kk': 'KK'
};

// 切换语言
function switchLanguage(lang) {
    if (!supportedLanguages.includes(lang)) {
        lang = 'zh';
    }
    
    currentLang = lang;
    localStorage.setItem('shanghe-lang', lang);
    
    // 更新所有带 data-i18n 属性的元素
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (i18n[lang] && i18n[lang][key]) {
            el.textContent = i18n[lang][key];
        }
    });
    
    // 更新语言切换按钮状态
    document.querySelectorAll('.lang-switch span').forEach(span => {
        span.classList.remove('active');
        const langName = languageNames[lang] || '中文';
        if (span.textContent === langName) {
            span.classList.add('active');
        }
    });
}

// 自动检测浏览器语言
function detectBrowserLanguage() {
    const browserLang = navigator.language || navigator.userLanguage;
    const langCode = browserLang.split('-')[0];
    
    // 如果浏览器语言在支持列表中，则使用
    if (supportedLanguages.includes(langCode)) {
        return langCode;
    }
    
    // 否则默认使用中文
    return 'zh';
}

// 页面加载时初始化语言
document.addEventListener('DOMContentLoaded', function() {
    // 优先使用 localStorage 保存的语言，如果没有则检测浏览器语言
    const savedLang = localStorage.getItem('shanghe-lang');
    const lang = savedLang || detectBrowserLanguage();
    switchLanguage(lang);
});
