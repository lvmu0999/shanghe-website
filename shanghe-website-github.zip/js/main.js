// 轮播图功能
class HeroSlider {
    constructor() {
        this.slides = document.querySelectorAll('.slide');
        this.dots = document.querySelectorAll('.dot');
        this.prevBtn = document.querySelector('.slider-btn.prev');
        this.nextBtn = document.querySelector('.slider-btn.next');
        this.currentIndex = 0;
        this.autoPlayInterval = null;
        
        this.init();
    }
    
    init() {
        // 绑定事件
        this.prevBtn.addEventListener('click', () => this.prev());
        this.nextBtn.addEventListener('click', () => this.next());
        
        this.dots.forEach(dot => {
            dot.addEventListener('click', (e) => {
                const index = parseInt(e.target.dataset.index);
                this.goToSlide(index);
            });
        });
        
        // 自动播放
        this.startAutoPlay();
        
        // 鼠标悬停暂停
        const hero = document.querySelector('.hero');
        hero.addEventListener('mouseenter', () => this.stopAutoPlay());
        hero.addEventListener('mouseleave', () => this.startAutoPlay());
    }
    
    goToSlide(index) {
        // 移除当前激活状态
        this.slides[this.currentIndex].classList.remove('active');
        this.dots[this.currentIndex].classList.remove('active');
        
        // 更新索引
        this.currentIndex = index;
        
        // 处理边界
        if (this.currentIndex < 0) {
            this.currentIndex = this.slides.length - 1;
        } else if (this.currentIndex >= this.slides.length) {
            this.currentIndex = 0;
        }
        
        // 添加激活状态
        this.slides[this.currentIndex].classList.add('active');
        this.dots[this.currentIndex].classList.add('active');
    }
    
    next() {
        this.goToSlide(this.currentIndex + 1);
    }
    
    prev() {
        this.goToSlide(this.currentIndex - 1);
    }
    
    startAutoPlay() {
        this.autoPlayInterval = setInterval(() => {
            this.next();
        }, 5000);
    }
    
    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
            this.autoPlayInterval = null;
        }
    }
}

// 数字动画
class NumberCounter {
    constructor() {
        this.counters = document.querySelectorAll('.stat-number');
        this.init();
    }
    
    init() {
        // 使用 Intersection Observer 检测元素是否进入视口
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.5
        });
        
        this.counters.forEach(counter => {
            observer.observe(counter);
        });
    }
    
    animateCounter(counter) {
        const target = parseInt(counter.dataset.target);
        const duration = 2000; // 2 秒
        const step = target / (duration / 16); // 60fps
        let current = 0;
        
        const updateCounter = () => {
            current += step;
            if (current < target) {
                counter.textContent = Math.floor(current).toLocaleString();
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target.toLocaleString();
            }
        };
        
        updateCounter();
    }
}

// 导航栏滚动效果
class NavbarScroll {
    constructor() {
        this.header = document.querySelector('.header');
        this.lastScroll = 0;
        this.init();
    }
    
    init() {
        window.addEventListener('scroll', () => this.handleScroll());
    }
    
    handleScroll() {
        const currentScroll = window.pageYOffset;
        
        // 添加滚动效果
        if (currentScroll > 100) {
            this.header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
        } else {
            this.header.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
        }
        
        this.lastScroll = currentScroll;
    }
}

// 平滑滚动
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
}

// 移动端菜单切换
function initMobileMenu() {
    const nav = document.querySelector('.nav');
    const header = document.querySelector('.header-content');
    
    // 创建切换按钮
    const menuToggle = document.createElement('button');
    menuToggle.className = 'menu-toggle';
    menuToggle.innerHTML = `
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
        </svg>
    `;
    
    menuToggle.addEventListener('click', () => {
        nav.classList.toggle('active');
    });
    
    // 在小屏时显示切换按钮
    if (window.innerWidth <= 768) {
        header.insertBefore(menuToggle, nav);
    }
    
    window.addEventListener('resize', () => {
        if (window.innerWidth <= 768) {
            if (!header.contains(menuToggle)) {
                header.insertBefore(menuToggle, nav);
            }
        } else {
            if (header.contains(menuToggle)) {
                header.removeChild(menuToggle);
            }
            nav.classList.remove('active');
        }
    });
}

// 搜索功能（简单实现）
function initSearch() {
    const searchBtn = document.querySelector('.search-btn');
    if (searchBtn) {
        searchBtn.addEventListener('click', () => {
            const searchTerm = prompt('请输入搜索关键词：');
            if (searchTerm) {
                alert(`搜索功能开发中...\n关键词：${searchTerm}`);
            }
        });
    }
}

// 语言切换功能
function initLangSwitch() {
    const langSpans = document.querySelectorAll('.lang-switch span[data-lang]');
    langSpans.forEach(span => {
        span.addEventListener('click', () => {
            langSpans.forEach(s => s.classList.remove('active'));
            span.classList.add('active');
            
            // 获取目标语言
            const targetLang = span.getAttribute('data-lang');
            
            // 使用 i18n.js 中的 switchLanguage 函数
            if (typeof switchLanguage === 'function') {
                switchLanguage(targetLang);
            }
        });
    });
}

// DOM 加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    // 初始化轮播图
    new HeroSlider();
    
    // 初始化数字动画
    new NumberCounter();
    
    // 初始化导航栏滚动效果
    new NavbarScroll();
    
    // 初始化平滑滚动
    initSmoothScroll();
    
    // 初始化移动端菜单
    initMobileMenu();
    
    // 初始化搜索
    initSearch();
    
    // 初始化语言切换
    initLangSwitch();
    
    console.log('上禾农业官网初始化完成！');
});

// 添加移动端菜单样式
const mobileMenuStyle = document.createElement('style');
mobileMenuStyle.textContent = `
    .menu-toggle {
        display: none;
        background: none;
        border: none;
        cursor: pointer;
        padding: 8px;
        color: var(--text-primary);
    }
    
    @media (max-width: 768px) {
        .menu-toggle {
            display: block;
        }
        
        .nav {
            display: none;
        }
        
        .nav.active {
            display: block;
        }
    }
`;
document.head.appendChild(mobileMenuStyle);
